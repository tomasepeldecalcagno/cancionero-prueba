"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Lock, X } from 'lucide-react'
import AuthManager from "@/lib/auth"

interface AuthDialogProps {
  isOpen: boolean
  onClose: () => void
  onSuccess: () => void
  action?: "create" | "edit" | "delete"
}

export default function AuthDialog({ 
  isOpen, 
  onClose, 
  onSuccess,
  action = "create"
}: AuthDialogProps) {
  const [code, setCode] = useState("")
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const getActionText = () => {
    switch (action) {
      case "create": return "crear canciones"
      case "edit": return "editar canciones"
      case "delete": return "eliminar canciones"
      default: return "gestionar canciones"
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    // Simular un pequeño delay para mejor UX
    await new Promise(resolve => setTimeout(resolve, 300))

    if (AuthManager.login(code)) {
      setCode("")
      setIsLoading(false)
      onSuccess()
      onClose()
    } else {
      setError("Código incorrecto")
      setIsLoading(false)
      // Limpiar el campo después de un error
      setTimeout(() => {
        setCode("")
        setError("")
      }, 1500)
    }
  }

  const handleClose = () => {
    setCode("")
    setError("")
    onClose()
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/20 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-sm border border-contemplative/20 shadow-lg bg-white/95 backdrop-blur-sm">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-contemplative/10 rounded-full flex items-center justify-center">
                <Lock className="w-3 h-3 text-contemplative" />
              </div>
              <span className="text-sm font-medium text-contemplative">Código requerido</span>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleClose}
              className="h-6 w-6 text-muted-foreground hover:text-foreground"
            >
              <X className="w-3 h-3" />
            </Button>
          </div>

          <p className="text-xs text-muted-foreground mb-3">
            Ingresa el código para {getActionText()}
          </p>

          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <Input
                type="password"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="Ingresa el código"
                className="h-9 text-sm border-contemplative/30 focus:border-contemplative/50"
                required
                disabled={isLoading}
                autoComplete="off"
                autoFocus
              />
              {error && (
                <p className="text-xs text-red-500 mt-1">{error}</p>
              )}
            </div>

            <div className="flex gap-2">
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={handleClose}
                className="flex-1 h-9 text-xs text-muted-foreground hover:text-foreground"
                disabled={isLoading}
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                size="sm"
                className="flex-1 h-9 text-xs bg-slate-800 hover:bg-slate-700 text-white font-semibold shadow-md disabled:bg-slate-400 disabled:text-slate-200"
                disabled={isLoading || !code.trim()}
              >
                {isLoading ? (
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 border border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Verificando</span>
                  </div>
                ) : (
                  "Confirmar"
                )}
              </Button>
            </div>

            {/* Texto de ayuda para móvil */}
            <p className="text-xs text-muted-foreground text-center sm:hidden">
              Toca "Confirmar" para enviar el código
            </p>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
