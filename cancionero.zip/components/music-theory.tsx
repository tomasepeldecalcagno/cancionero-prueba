"use client"

/**
 * Sistema completo de teoría musical con equivalencias enarmónicas correctas
 */
export class MusicTheory {
  // Círculo cromático base
  static readonly CHROMATIC_CIRCLE = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]

  // ✅ MAPEO CORREGIDO - RECONOCIENDO BEMOLES CORRECTAMENTE
  static readonly NOTE_TO_CHROMATIC: { [key: string]: string } = {
    // Inglés estándar
    C: "C",
    "C#": "C#",
    Db: "C#",
    D: "D",
    "D#": "D#",
    Eb: "D#",
    E: "E",
    F: "F",
    "F#": "F#",
    Gb: "F#",
    G: "G",
    "G#": "G#",
    Ab: "G#",
    A: "A",
    "A#": "A#",
    Bb: "A#", // ✅ Bb = A#
    B: "B",

    // Español mayúscula - ✅ BEMOLES CORREGIDOS
    DO: "C",
    "DO#": "C#",
    DOb: "B", // DOb = B
    REB: "C#", // REb = C#
    RE: "D",
    "RE#": "D#",
    REb: "C#", // REb = C#
    MIB: "D#", // MIb = D#
    MI: "E",
    MIb: "D#", // MIb = D#
    FA: "F",
    "FA#": "F#",
    FAb: "E", // FAb = E
    SOLB: "F#", // SOLb = F#
    SOL: "G",
    "SOL#": "G#",
    SOLb: "F#", // SOLb = F#
    LAB: "G#", // LAb = G#
    LA: "A",
    "LA#": "A#",
    LAb: "G#", // LAb = G#
    SIB: "A#", // ✅ SIb = A# (NO B!)
    SI: "B",
    SIb: "A#", // ✅ SIb = A# (NO B!)

    // Español capitalizado - ✅ BEMOLES CORREGIDOS
    Do: "C",
    "Do#": "C#",
    Dob: "B",
    Reb: "C#",
    Re: "D",
    "Re#": "D#",
    Reb: "C#",
    Mib: "D#",
    Mi: "E",
    Fa: "F",
    "Fa#": "F#",
    Fab: "E",
    Solb: "F#",
    Sol: "G",
    "Sol#": "G#",
    Lab: "G#",
    La: "A",
    "La#": "A#",
    Sib: "A#", // ✅ Sib = A#
    Si: "B",

    // Minúsculas - ✅ BEMOLES CORREGIDOS
    c: "C",
    "c#": "C#",
    db: "C#",
    d: "D",
    "d#": "D#",
    eb: "D#",
    e: "E",
    f: "F",
    "f#": "F#",
    gb: "F#",
    g: "G",
    "g#": "G#",
    ab: "G#",
    a: "A",
    "a#": "A#",
    bb: "A#",
    b: "B",
    do: "C",
    "do#": "C#",
    dob: "B",
    reb: "C#",
    re: "D",
    "re#": "D#",
    mib: "D#",
    mi: "E",
    fa: "F",
    "fa#": "F#",
    fab: "E",
    solb: "F#",
    sol: "G",
    "sol#": "G#",
    lab: "G#",
    la: "A",
    "la#": "A#",
    sib: "A#", // ✅ sib = A#
    si: "B",
  }

  // ✅ MAPEO CROMÁTICO A ESPAÑOL CORREGIDO
  static readonly CHROMATIC_TO_SPANISH = {
    C: {
      natural: { upper: "DO", lower: "do", title: "Do" },
    },
    "C#": {
      sharp: { upper: "DO#", lower: "do#", title: "Do#" },
      flat: { upper: "REb", lower: "reb", title: "Reb" },
      natural: { upper: "DO#", lower: "do#", title: "Do#" },
    },
    D: {
      natural: { upper: "RE", lower: "re", title: "Re" },
    },
    "D#": {
      sharp: { upper: "RE#", lower: "re#", title: "Re#" },
      flat: { upper: "MIb", lower: "mib", title: "Mib" },
      natural: { upper: "RE#", lower: "re#", title: "Re#" },
    },
    E: {
      natural: { upper: "MI", lower: "mi", title: "Mi" },
    },
    F: {
      natural: { upper: "FA", lower: "fa", title: "Fa" },
    },
    "F#": {
      sharp: { upper: "FA#", lower: "fa#", title: "Fa#" },
      flat: { upper: "SOLb", lower: "solb", title: "Solb" },
      natural: { upper: "FA#", lower: "fa#", title: "Fa#" },
    },
    G: {
      natural: { upper: "SOL", lower: "sol", title: "Sol" },
    },
    "G#": {
      sharp: { upper: "SOL#", lower: "sol#", title: "Sol#" },
      flat: { upper: "LAb", lower: "lab", title: "Lab" },
      natural: { upper: "SOL#", lower: "sol#", title: "Sol#" },
    },
    A: {
      natural: { upper: "LA", lower: "la", title: "La" },
    },
    "A#": {
      sharp: { upper: "LA#", lower: "la#", title: "La#" },
      flat: { upper: "SIb", lower: "sib", title: "Sib" }, // ✅ A# = SIb
      natural: { upper: "LA#", lower: "la#", title: "La#" },
    },
    B: {
      natural: { upper: "SI", lower: "si", title: "Si" },
    },
  }

  // ✅ MAPEO CROMÁTICO A INGLÉS
  static readonly CHROMATIC_TO_ENGLISH = {
    C: "C",
    "C#": "C#",
    D: "D",
    "D#": "D#",
    E: "E",
    F: "F",
    "F#": "F#",
    G: "G",
    "G#": "G#",
    A: "A",
    "A#": "A#",
    B: "B",
  }

  // Tonalidades y sus alteraciones preferidas
  static readonly KEY_SIGNATURES: { [key: string]: { prefersSharps: boolean } } = {
    // Tonalidades con sostenidos
    C: { prefersSharps: true },
    G: { prefersSharps: true },
    D: { prefersSharps: true },
    A: { prefersSharps: true },
    E: { prefersSharps: true },
    B: { prefersSharps: true },
    "F#": { prefersSharps: true },
    "C#": { prefersSharps: true },

    // Tonalidades con bemoles
    F: { prefersSharps: false },
    Bb: { prefersSharps: false },
    Eb: { prefersSharps: false },
    Ab: { prefersSharps: false },
    Db: { prefersSharps: false },
    Gb: { prefersSharps: false },
    Cb: { prefersSharps: false },

    // Tonalidades menores
    Am: { prefersSharps: true },
    Em: { prefersSharps: true },
    Bm: { prefersSharps: true },
    "F#m": { prefersSharps: true },
    "C#m": { prefersSharps: true }, // ✅ C#m usa sostenidos
    "G#m": { prefersSharps: true },
    "D#m": { prefersSharps: true },
    "A#m": { prefersSharps: true },

    Dm: { prefersSharps: false },
    Gm: { prefersSharps: false },
    Cm: { prefersSharps: false },
    Fm: { prefersSharps: false },
    Bbm: { prefersSharps: false },
    Ebm: { prefersSharps: false },
    Abm: { prefersSharps: false },
  }

  /**
   * Detecta el formato predominante en una canción
   */
  static detectSongFormat(lyrics: string): {
    isSpanish: boolean
    caseStyle: "upper" | "lower" | "title"
  } {
    // ✅ REGEX MEJORADO PARA RECONOCER BEMOLES
    const chordMatches = lyrics.match(
      /\b([A-G][#b♯♭]?|DO|RE|MI|FA|SOL|LA|SI|Do|Re|Mi|Fa|Sol|La|Si|do|re|mi|fa|sol|la|si)([#b♯♭]?)(m|maj|min|dim|aug|sus[24]?|add[0-9]+|M?[0-9]+|[+°])*(\/?[A-G#b♯♭]*)?/g,
    )

    if (!chordMatches || chordMatches.length === 0) {
      return { isSpanish: false, caseStyle: "upper" }
    }

    let spanishCount = 0
    let englishCount = 0
    let upperCount = 0
    let lowerCount = 0
    let titleCount = 0

    chordMatches.forEach((chord) => {
      // ✅ REGEX MEJORADO PARA CAPTURAR BEMOLES CORRECTAMENTE
      const rootMatch = chord.match(
        /^([A-G][#b♯♭]?|DO[#b♯♭]?|RE[#b♯♭]?|MI[#b♯♭]?|FA[#b♯♭]?|SOL[#b♯♭]?|LA[#b♯♭]?|SI[#b♯♭]?|Do[#b♯♭]?|Re[#b♯♭]?|Mi[#b♯♭]?|Fa[#b♯♭]?|Sol[#b♯♭]?|La[#b♯♭]?|Si[#b♯♭]?|do[#b♯♭]?|re[#b♯♭]?|mi[#b♯♭]?|fa[#b♯♭]?|sol[#b♯♭]?|la[#b♯♭]?|si[#b♯♭]?)/,
      )
      if (!rootMatch) return

      const root = rootMatch[1]

      if (/^(DO|RE|MI|FA|SOL|LA|SI|Do|Re|Mi|Fa|Sol|La|Si|do|re|mi|fa|sol|la|si)/i.test(root)) {
        spanishCount++
      } else {
        englishCount++
      }

      if (root === root.toUpperCase()) {
        upperCount++
      } else if (root === root.toLowerCase()) {
        lowerCount++
      } else {
        titleCount++
      }
    })

    const isSpanish = spanishCount > englishCount
    const caseStyle =
      upperCount >= lowerCount && upperCount >= titleCount ? "upper" : lowerCount >= titleCount ? "lower" : "title"

    console.log(`🎵 Song format: ${isSpanish ? "Spanish" : "English"}, ${caseStyle}`)
    return { isSpanish, caseStyle }
  }

  /**
   * ✅ ANÁLISIS DE ACORDE MEJORADO PARA RECONOCER BEMOLES
   */
  static parseChord(
    chord: string,
    songFormat?: { isSpanish: boolean; caseStyle: "upper" | "lower" | "title" },
  ): {
    root: string
    suffix: string
    bassNote?: string
    originalRoot: string
    originalBass?: string
    isSpanish: boolean
    caseStyle: "upper" | "lower" | "title"
  } {
    const parts = chord.split("/")
    const mainChord = parts[0].trim()
    const bassNote = parts[1]?.trim()

    // ✅ REGEX CORREGIDO PARA CAPTURAR BEMOLES CORRECTAMENTE
    const match = mainChord.match(
      /^(DO[#b♯♭]?|RE[#b♯♭]?|MI[#b♯♭]?|FA[#b♯♭]?|SOL[#b♯♭]?|LA[#b♯♭]?|SI[#b♯♭]?|Do[#b♯♭]?|Re[#b♯♭]?|Mi[#b♯♭]?|Fa[#b♯♭]?|Sol[#b♯♭]?|La[#b♯♭]?|Si[#b♯♭]?|do[#b♯♭]?|re[#b♯♭]?|mi[#b♯♭]?|fa[#b♯♭]?|sol[#b♯♭]?|la[#b♯♭]?|si[#b♯♭]?|[A-G][#b♯♭]?)(.*)$/i,
    )

    if (!match) {
      console.warn(`Could not parse chord: ${chord}`)
      return {
        root: "C",
        suffix: "",
        originalRoot: chord,
        isSpanish: songFormat?.isSpanish || false,
        caseStyle: songFormat?.caseStyle || "upper",
      }
    }

    const [, fullNote, suffix] = match

    console.log(`🎵 Parsing chord: "${chord}" → fullNote: "${fullNote}", suffix: "${suffix}"`)

    // Validar que la nota existe en nuestro mapeo
    const chromaticRoot = this.NOTE_TO_CHROMATIC[fullNote]
    if (!chromaticRoot) {
      console.warn(`Unknown note: ${fullNote} in chord: ${chord}`)
      console.log(`Available notes:`, Object.keys(this.NOTE_TO_CHROMATIC))
      return {
        root: "C",
        suffix: "",
        originalRoot: chord,
        isSpanish: songFormat?.isSpanish || false,
        caseStyle: songFormat?.caseStyle || "upper",
      }
    }

    console.log(`   Chromatic mapping: "${fullNote}" → "${chromaticRoot}"`)

    let isSpanish: boolean
    let caseStyle: "upper" | "lower" | "title"

    if (songFormat) {
      isSpanish = songFormat.isSpanish
      caseStyle = songFormat.caseStyle
    } else {
      isSpanish = /^(DO|RE|MI|FA|SOL|LA|SI|Do|Re|Mi|Fa|Sol|La|Si|do|re|mi|fa|sol|la|si)/i.test(fullNote)
      caseStyle =
        fullNote === fullNote.toUpperCase() ? "upper" : fullNote === fullNote.toLowerCase() ? "lower" : "title"
    }

    let chromaticBass: string | undefined
    let originalBass: string | undefined

    if (bassNote) {
      originalBass = bassNote
      chromaticBass = this.NOTE_TO_CHROMATIC[bassNote]
      if (!chromaticBass) {
        console.warn(`Unknown bass note: ${bassNote}`)
        chromaticBass = bassNote // Mantener original si no se puede mapear
      }
    }

    return {
      root: chromaticRoot,
      suffix: suffix,
      bassNote: chromaticBass,
      originalRoot: fullNote,
      originalBass: originalBass,
      isSpanish: isSpanish,
      caseStyle: caseStyle,
    }
  }

  /**
   * Transpone una nota cromática
   */
  static transposeNote(chromaticNote: string, semitones: number): string {
    const currentIndex = this.CHROMATIC_CIRCLE.indexOf(chromaticNote)
    if (currentIndex === -1) return chromaticNote

    const newIndex = (currentIndex + semitones + 12) % 12
    const result = this.CHROMATIC_CIRCLE[newIndex]

    console.log(
      `   Transposing: ${chromaticNote} (index ${currentIndex}) + ${semitones} → ${result} (index ${newIndex})`,
    )
    return result
  }

  /**
   * ✅ FORMATEO CORREGIDO DE NOTAS ESPAÑOLAS
   */
  static formatNote(
    chromaticNote: string,
    isSpanish: boolean,
    caseStyle: "upper" | "lower" | "title",
    targetKey?: string,
  ): string {
    console.log(`🎵 Formatting note: ${chromaticNote}, Spanish: ${isSpanish}, Case: ${caseStyle}, Target: ${targetKey}`)

    if (!isSpanish) {
      // Notación inglesa
      const englishNote = this.CHROMATIC_TO_ENGLISH[chromaticNote as keyof typeof this.CHROMATIC_TO_ENGLISH]
      const result = caseStyle === "lower" ? englishNote.toLowerCase() : englishNote
      console.log(`   English result: ${result}`)
      return result
    }

    // ✅ NOTACIÓN ESPAÑOLA CORREGIDA
    const spanishNote = this.CHROMATIC_TO_SPANISH[chromaticNote as keyof typeof this.CHROMATIC_TO_SPANISH]
    if (!spanishNote) {
      console.warn(`No Spanish mapping found for: ${chromaticNote}`)
      return chromaticNote
    }

    // Determinar si usar sostenidos o bemoles basado en la tonalidad objetivo
    const keyInfo = targetKey ? this.KEY_SIGNATURES[targetKey] : null
    const useFlats = keyInfo && !keyInfo.prefersSharps

    console.log(`   Key info: ${targetKey}, Use flats: ${useFlats}`)

    // Seleccionar la variante correcta
    let variant
    if (useFlats && spanishNote.flat) {
      variant = spanishNote.flat
      console.log(`   Using flat variant: ${variant.upper}`)
    } else if (spanishNote.sharp && chromaticNote.includes("#")) {
      variant = spanishNote.sharp
      console.log(`   Using sharp variant: ${variant.upper}`)
    } else {
      variant = spanishNote.natural
      console.log(`   Using natural variant: ${variant.upper}`)
    }

    if (!variant) {
      variant = spanishNote.natural || spanishNote.sharp || spanishNote.flat
      console.log(`   Fallback variant: ${variant.upper}`)
    }

    let result: string
    switch (caseStyle) {
      case "upper":
        result = variant.upper
        break
      case "lower":
        result = variant.lower
        break
      case "title":
        result = variant.title
        break
      default:
        result = variant.upper
    }

    console.log(`   Final Spanish result: ${result}`)
    return result
  }

  /**
   * ✅ TRANSPOSICIÓN CORREGIDA CON VALIDACIÓN ESTRICTA Y MEJOR MANEJO DE REEMPLAZOS
   */
  static transposeChord(
    chord: string,
    semitones: number,
    songFormat?: { isSpanish: boolean; caseStyle: "upper" | "lower" | "title" },
    targetKey?: string,
  ): string {
    if (semitones === 0) return chord

    console.log(`🎵 Transposing chord: "${chord}" by ${semitones} semitones`)
    console.log(`   Song format: Spanish=${songFormat?.isSpanish}, Case=${songFormat?.caseStyle}`)
    console.log(`   Target key: ${targetKey}`)

    // Limpiar el acorde de espacios extra
    const cleanChord = chord.trim()
    if (!cleanChord) return chord

    const parsed = this.parseChord(cleanChord, songFormat)
    console.log(`   Parsed chord:`, parsed)

    // Validar que el acorde sea válido antes de transponer
    if (!this.CHROMATIC_CIRCLE.includes(parsed.root)) {
      console.warn(`   Invalid chord root: ${parsed.root}, returning original: ${chord}`)
      return chord
    }

    // Transponer la raíz
    const newRoot = this.transposeNote(parsed.root, semitones)
    console.log(`   Root transposition: ${parsed.root} → ${newRoot}`)

    // Asegurar que usamos el formato detectado de la canción
    const useSpanish = songFormat?.isSpanish ?? parsed.isSpanish
    const useCaseStyle = songFormat?.caseStyle ?? parsed.caseStyle

    const formattedRoot = this.formatNote(newRoot, useSpanish, useCaseStyle, targetKey)
    console.log(`   Formatted root: ${formattedRoot}`)

    // Transponer el bajo si existe
    let formattedBass: string | undefined
    if (parsed.bassNote) {
      const newBass = this.transposeNote(parsed.bassNote, semitones)
      formattedBass = this.formatNote(newBass, useSpanish, useCaseStyle, targetKey)
      console.log(`   Bass transposition: ${parsed.bassNote} → ${newBass} → ${formattedBass}`)
    }

    // Construir resultado manteniendo el sufijo exacto
    let result = formattedRoot + parsed.suffix
    if (formattedBass) {
      result += "/" + formattedBass
    }

    // Validar el resultado final
    if (!this.isValidChord(result)) {
      console.warn(`   Invalid result chord: ${result}, returning original: ${chord}`)
      return chord
    }

    console.log(`   Final result: "${chord}" → "${result}"`)
    return result
  }

  /**
   * ✅ CÁLCULO DE SEMITONOS CORREGIDO
   */
  static calculateSemitones(fromKey: string, toKey: string): number {
    console.log(`🔢 Calculating semitones: ${fromKey} → ${toKey}`)

    const fromRoot = this.parseChord(fromKey).root
    const toRoot = this.parseChord(toKey).root

    console.log(`   Parsed roots: ${fromRoot} → ${toRoot}`)

    const fromIndex = this.CHROMATIC_CIRCLE.indexOf(fromRoot)
    const toIndex = this.CHROMATIC_CIRCLE.indexOf(toRoot)

    console.log(`   Chromatic indices: ${fromIndex} → ${toIndex}`)

    if (fromIndex === -1 || toIndex === -1) {
      console.error(`   Invalid indices: fromIndex=${fromIndex}, toIndex=${toIndex}`)
      return 0
    }

    // ✅ CÁLCULO CORRECTO DE SEMITONOS
    let semitones = toIndex - fromIndex

    // Normalizar al rango 0-11
    if (semitones < 0) {
      semitones += 12
    }

    // Usar la distancia más corta (máximo 6 semitonos)
    if (semitones > 6) {
      semitones -= 12
    }

    console.log(`   Final semitones: ${semitones}`)
    console.log(`   Verification: ${fromRoot} + ${semitones} = ${this.transposeNote(fromRoot, semitones)}`)

    return semitones
  }

  /**
   * Valida si un acorde es correcto
   */
  static isValidChord(chord: string): boolean {
    // Rechazar acordes malformados
    if (chord.includes("DOO#") || chord.includes("doo#") || chord.includes("CO#")) {
      console.warn(`Invalid chord detected: ${chord}`)
      return false
    }

    const parsed = this.parseChord(chord)
    return this.CHROMATIC_CIRCLE.includes(parsed.root)
  }

  /**
   * Obtiene tonalidades comunes
   */
  static getCommonKeys(): string[] {
    return [
      "C",
      "G",
      "D",
      "A",
      "E",
      "B",
      "F#",
      "F",
      "Bb",
      "Eb",
      "Ab",
      "Db",
      "Am",
      "Em",
      "Bm",
      "F#m",
      "C#m",
      "G#m",
      "D#m",
      "Dm",
      "Gm",
      "Cm",
      "Fm",
      "Bbm",
    ]
  }
}

export default MusicTheory
