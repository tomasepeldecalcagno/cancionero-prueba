"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Save, HelpCircle, Sparkles, Upload, Volume2, X, Cross } from 'lucide-react'
import { Alert, AlertDescription } from "@/components/ui/alert"
import ChordRecognition from "@/components/chord-recognition"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Song {
  id: string
  title: string
  artist?: string
  lyrics: string
  original_key?: string
  audio_file?: string
  audio_file_name?: string
  category: "misa" | "general"
  created_at?: string
  updated_at?: string
}

interface SongFormProps {
  song?: Song
  onSave: (song: Omit<Song, "id"> | Song) => void
  onCancel: () => void
}

export default function SongForm({ song, onSave, onCancel }: SongFormProps) {
  const [title, setTitle] = useState(song?.title || "")
  const [lyrics, setLyrics] = useState(song?.lyrics || "")
  const [audioFile, setAudioFile] = useState<string | undefined>(song?.audio_file)
  const [audioFileName, setAudioFileName] = useState<string | undefined>(song?.audio_file_name)
  const [isUploading, setIsUploading] = useState(false)
  const [category, setCategory] = useState<"misa" | "general">(song?.category || "general") // Agregar esta línea

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!title.trim() || !lyrics.trim()) {
      alert("Por favor completa todos los campos")
      return
    }

    const songData = {
      title: title.trim(),
      lyrics: lyrics.trim(),
      original_key: extractKey(lyrics),
      audio_file: audioFile,
      audio_file_name: audioFileName,
      category,
    }

    if (song) {
      onSave({ ...songData, id: song.id })
    } else {
      onSave(songData)
    }
  }

  const extractKey = (lyricsText: string): string => {
    try {
      // Usar el nuevo sistema de reconocimiento
      const analysis = ChordRecognition.analyzeLyrics(lyricsText)
      return analysis.detectedKey
    } catch (error) {
      console.error("Error detecting key:", error)
      return "C"
    }
  }

  const handleAudioUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Verificar tipo de archivo
    const allowedTypes = ["audio/mpeg", "audio/wav", "audio/ogg", "audio/mp3", "audio/m4a"]
    if (!allowedTypes.includes(file.type) && !file.name.match(/\.(mp3|wav|ogg|m4a)$/i)) {
      alert("Por favor selecciona un archivo de audio válido (MP3, WAV, OGG, M4A)")
      return
    }

    // Verificar tamaño (máximo 10MB)
    if (file.size > 10 * 1024 * 1024) {
      alert("El archivo es demasiado grande. Máximo 10MB.")
      return
    }

    setIsUploading(true)
    const reader = new FileReader()

    reader.onload = (event) => {
      const result = event.target?.result as string
      setAudioFile(result)
      setAudioFileName(file.name)
      setIsUploading(false)
    }

    reader.onerror = () => {
      alert("Error al cargar el archivo")
      setIsUploading(false)
    }

    reader.readAsDataURL(file)
  }

  const removeAudio = () => {
    setAudioFile(undefined)
    setAudioFileName(undefined)
  }

  const formatExamples = ChordRecognition.getFormatExamples()

  return (
    <div className="max-w-7xl mx-auto space-y-6 sm:space-y-8 px-3 sm:px-4 lg:px-6">
      {/* Header Responsive */}
      <div className="flex flex-col sm:flex-row items-start gap-4">
        <Button
          variant="ghost"
          onClick={onCancel}
          className="p-2 sm:p-3 text-contemplative hover:text-reflective hover:bg-reflective/10 transition-all duration-300 w-full sm:w-auto justify-center sm:justify-start"
        >
          <ArrowLeft className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
          Volver
        </Button>
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="w-8 h-8 sm:w-10 sm:h-10 bg-gradient-to-br from-contemplative to-reflective rounded-full flex items-center justify-center">
            <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-background" />
          </div>
          <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-contemplative">
            {song ? "Editar Canción" : "Nueva Canción"} del Cancionero
          </h1>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Formulario Responsive */}
        <Card className="order-2 lg:order-1 border-reflective/30 shadow-lg bg-gradient-to-br from-background to-muted/10">
          <CardHeader className="px-4 sm:px-6 py-4 sm:py-6">
            <CardTitle className="text-lg sm:text-xl text-contemplative flex items-center gap-2">
              <Save className="w-4 h-4 sm:w-5 sm:h-5" />
              Información de la Canción
            </CardTitle>
          </CardHeader>
          <CardContent className="px-4 sm:px-6 pb-4 sm:pb-6">
            <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
              <div className="space-y-2">
                <Label htmlFor="title" className="text-sm font-semibold text-foreground">
                  Título *
                </Label>
                <Input
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Ej: Cordero de Dios"
                  className="h-10 sm:h-12 border-2 border-reflective/30 focus:border-contemplative/50 transition-all duration-300 text-sm sm:text-base"
                  required
                />
              </div>

              {/* Selector de Categoría Responsive */}
              <div className="space-y-2">
                <Label htmlFor="category" className="text-sm font-semibold text-foreground">
                  Categoría *
                </Label>
                <Select value={category} onValueChange={(value: "misa" | "general") => setCategory(value)}>
                  <SelectTrigger className="h-10 sm:h-12 border-2 border-reflective/30 focus:border-contemplative/50 transition-all duration-300 text-sm sm:text-base">
                    <SelectValue placeholder="Selecciona una categoría" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="misa">
                      <div className="flex items-center gap-2">
                        <Cross className="w-3 h-3 sm:w-4 sm:h-4 text-contemplative" />
                        <span className="text-sm sm:text-base">Cancionero de Misa</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="general">
                      <div className="flex items-center gap-2">
                        <Cross className="w-3 h-3 sm:w-4 sm:h-4 text-reflective" />
                        <span className="text-sm sm:text-base">Cancionero</span>
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Audio Upload Responsive */}
              <div className="space-y-2">
                <Label htmlFor="audio" className="text-sm font-semibold text-foreground">
                  Archivo de Audio (Opcional)
                </Label>
                {!audioFile ? (
                  <div className="border-2 border-dashed border-reflective/30 rounded-lg p-4 sm:p-6 text-center hover:border-contemplative/50 transition-all duration-300">
                    <Upload className="w-6 h-6 sm:w-8 sm:h-8 text-muted-foreground mx-auto mb-2 sm:mb-3" />
                    <p className="text-xs sm:text-sm text-muted-foreground mb-2 sm:mb-3 px-2">
                      Arrastra un archivo de audio aquí o haz clic para seleccionar
                    </p>
                    <Input
                      id="audio"
                      type="file"
                      accept="audio/*,.mp3,.wav,.ogg,.m4a"
                      onChange={handleAudioUpload}
                      className="hidden"
                      disabled={isUploading}
                    />
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => document.getElementById("audio")?.click()}
                      disabled={isUploading}
                      className="w-full sm:w-auto bg-transparent border-2 border-reflective/50 text-contemplative hover:text-reflective hover:border-reflective/50 transition-all duration-300 text-xs sm:text-sm"
                    >
                      {isUploading ? "Subiendo..." : "Seleccionar Archivo"}
                    </Button>
                    <p className="text-xs text-muted-foreground mt-2">Formatos: MP3, WAV, OGG, M4A (máx. 10MB)</p>
                  </div>
                ) : (
                  <div className="border-2 border-reflective/30 rounded-lg p-3 sm:p-4 bg-gradient-to-r from-reflective/10 to-contemplative/10">
                    <div className="flex items-center justify-between mb-2 sm:mb-3">
                      <div className="flex items-center gap-2 flex-1 min-w-0">
                        <Volume2 className="w-4 h-4 sm:w-5 sm:h-5 text-reflective flex-shrink-0" />
                        <span className="text-xs sm:text-sm font-medium text-foreground truncate">{audioFileName}</span>
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={removeAudio}
                        className="h-6 w-6 sm:h-8 sm:w-8 text-destructive hover:text-destructive hover:bg-destructive/10 flex-shrink-0"
                      >
                        <X className="w-3 h-3 sm:w-4 sm:h-4" />
                      </Button>
                    </div>
                    <audio controls className="w-full h-8 sm:h-10 rounded-md" preload="metadata">
                      <source src={audioFile} type="audio/mpeg" />
                      <source src={audioFile} type="audio/wav" />
                      <source src={audioFile} type="audio/ogg" />
                      Tu navegador no soporta el elemento de audio.
                    </audio>
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="lyrics" className="text-sm font-semibold text-foreground">
                  Letra con Acordes *
                </Label>
                <Textarea
                  id="lyrics"
                  value={lyrics}
                  onChange={(e) => setLyrics(e.target.value)}
                  placeholder="Escribe la letra con los acordes en la línea superior..."
                  className="min-h-[250px] sm:min-h-[300px] lg:min-h-[350px] font-mono text-xs sm:text-sm border-2 border-reflective/30 focus:border-contemplative/50 transition-all duration-300"
                  required
                />
              </div>

              <div className="flex flex-col sm:flex-row gap-3 pt-2 sm:pt-4">
                <Button
                  type="submit"
                  className="w-full sm:flex-1 h-10 sm:h-12 bg-gradient-to-r from-contemplative to-reflective hover:from-contemplative/90 hover:to-reflective/90 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 text-sm sm:text-base"
                >
                  <Save className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
                  {song ? "Actualizar" : "Guardar"} Canción
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={onCancel}
                  className="w-full sm:w-auto h-10 sm:h-12 bg-transparent border-2 border-reflective/50 text-contemplative hover:text-reflective hover:border-reflective/50 transition-all duration-300 text-sm sm:text-base"
                >
                  Cancelar
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Ayuda y ejemplo Responsive */}
        <div className="space-y-4 sm:space-y-6 order-1 lg:order-2">
          <Alert className="bg-gradient-to-r from-reflective/10 to-contemplative/10 border-2 border-reflective/30 shadow-lg">
            <HelpCircle className="h-4 w-4 sm:h-5 sm:w-5 text-reflective" />
            <AlertDescription className="text-xs sm:text-sm">
              <strong className="text-contemplative">Formato Correcto:</strong>
              <br />
              Coloca los acordes en una línea separada, luego la letra en la siguiente línea. Los acordes se detectarán
              automáticamente para facilitar la alabanza en comunidad.
            </AlertDescription>
          </Alert>

          <Alert className="bg-gradient-to-r from-reflective/10 to-contemplative/10 border-2 border-reflective/30 shadow-lg">
            <Volume2 className="h-4 w-4 sm:h-5 sm:w-5 text-reflective" />
            <AlertDescription className="text-xs sm:text-sm">
              <strong className="text-contemplative">Ejemplo de tu canción:</strong>
              <br />
              <code className="text-xs bg-muted/50 p-1 rounded block mt-1">
                DO SOL LAm FA
                <br />
                Gloria, gloria, a Jesús el Señor
              </code>
            </AlertDescription>
          </Alert>

          <div className="space-y-3 sm:space-y-4">
            {formatExamples.map((example, index) => (
              <Card
                key={index}
                className="border-reflective/30 shadow-lg bg-gradient-to-br from-background to-muted/10"
              >
                <CardHeader className="px-4 sm:px-6 py-3 sm:py-4">
                  <CardTitle className="text-base sm:text-lg text-contemplative flex items-center gap-2">
                    <Sparkles className="w-3 h-3 sm:w-4 sm:h-4" />
                    {example.title}
                  </CardTitle>
                  <p className="text-xs sm:text-sm text-muted-foreground">{example.description}</p>
                </CardHeader>
                <CardContent className="px-4 sm:px-6 pb-4 sm:pb-6">
                  <pre className="text-xs bg-gradient-to-br from-muted/50 to-reflective/10 p-3 sm:p-4 rounded-lg border border-reflective/30 overflow-x-auto whitespace-pre-wrap font-mono text-foreground shadow-inner">
                    {example.example}
                  </pre>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="border-reflective/30 shadow-lg bg-gradient-to-br from-background to-muted/10">
            <CardHeader className="px-4 sm:px-6 py-3 sm:py-4">
              <CardTitle className="text-base sm:text-lg text-contemplative">Acordes soportados</CardTitle>
            </CardHeader>
            <CardContent className="px-4 sm:px-6 pb-4 sm:pb-6">
              <div className="text-xs sm:text-sm space-y-2 sm:space-y-3 text-foreground">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-contemplative rounded-full flex-shrink-0"></div>
                  <span>
                    <strong className="text-contemplative">Inglés:</strong> C, D, E, F, G, A, B
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-reflective rounded-full flex-shrink-0"></div>
                  <span>
                    <strong className="text-contemplative">Español:</strong> DO, RE, MI, FA, SOL, LA, SI
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-reflective rounded-full flex-shrink-0"></div>
                  <span>
                    <strong className="text-contemplative">Con sufijos:</strong> REm, SOLm, LA7, etc.
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
