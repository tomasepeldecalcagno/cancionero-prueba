"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Shield, LogOut, Clock, User } from 'lucide-react'
import AuthManager from "@/lib/auth"

interface AuthStatusProps {
  onLogout?: () => void
}

export default function AuthStatus({ onLogout }: AuthStatusProps) {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [timeRemaining, setTimeRemaining] = useState(0)

  useEffect(() => {
    // Verificar estado inicial
    setIsAuthenticated(AuthManager.isAuthenticated())
    setTimeRemaining(AuthManager.getSessionTimeRemaining())

    // Actualizar cada minuto
    const interval = setInterval(() => {
      const authenticated = AuthManager.isAuthenticated()
      setIsAuthenticated(authenticated)
      
      if (authenticated) {
        setTimeRemaining(AuthManager.getSessionTimeRemaining())
        // Extender sesión si está activo
        AuthManager.extendSession()
      } else {
        setTimeRemaining(0)
      }
    }, 60000) // Cada minuto

    return () => clearInterval(interval)
  }, [])

  const handleLogout = () => {
    AuthManager.logout()
    setIsAuthenticated(false)
    setTimeRemaining(0)
    onLogout?.()
  }

  if (!isAuthenticated) return null

  const formatTime = (minutes: number): string => {
    if (minutes < 60) {
      return `${minutes}m`
    }
    const hours = Math.floor(minutes / 60)
    const remainingMinutes = minutes % 60
    return `${hours}h ${remainingMinutes}m`
  }

  return (
    <Card className="border-2 border-contemplative/30 bg-gradient-to-r from-contemplative/10 to-reflective/10">
      <CardContent className="p-3 sm:p-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4">
          <div className="flex items-center gap-2 flex-1">
            <div className="w-8 h-8 bg-gradient-to-br from-contemplative to-reflective rounded-full flex items-center justify-center">
              <User className="w-4 h-4 text-white" />
            </div>
            <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-3">
              <Badge variant="secondary" className="bg-contemplative/20 text-contemplative border-contemplative/30 text-xs w-fit">
                <Shield className="w-3 h-3 mr-1" />
                Administrador
              </Badge>
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Clock className="w-3 h-3" />
                <span>Sesión: {formatTime(timeRemaining)}</span>
              </div>
            </div>
          </div>
          
          <Button
            variant="outline"
            size="sm"
            onClick={handleLogout}
            className="w-full sm:w-auto bg-transparent border-contemplative/30 text-contemplative hover:bg-contemplative/10 hover:border-contemplative/50 text-xs"
          >
            <LogOut className="w-3 h-3 mr-1" />
            Cerrar Sesión
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
