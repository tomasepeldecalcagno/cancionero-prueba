"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Play, Pause, Settings } from "lucide-react"

interface MetronomeProps {
  className?: string
}

export default function Metronome({ className }: MetronomeProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [bpm, setBpm] = useState(120)
  const [beat, setBeat] = useState(0)
  const [isMuted, setIsMuted] = useState(false)
  const [showControls, setShowControls] = useState(false)
  const intervalRef = useRef<NodeJS.Timeout | null>(null)
  const audioContextRef = useRef<AudioContext | null>(null)

  // Crear contexto de audio para el sonido del metrónomo
  useEffect(() => {
    if (typeof window !== "undefined") {
      try {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)()
      } catch (error) {
        console.log("Audio context not supported")
      }
    }
  }, [])

  // Función para reproducir el sonido del metrónomo
  const playClick = (isAccent = false) => {
    if (isMuted || !audioContextRef.current) return

    try {
      const audioContext = audioContextRef.current
      const oscillator = audioContext.createOscillator()
      const gainNode = audioContext.createGain()

      oscillator.connect(gainNode)
      gainNode.connect(audioContext.destination)

      // Sonido más agudo para el primer beat (acento)
      oscillator.frequency.setValueAtTime(isAccent ? 800 : 600, audioContext.currentTime)
      oscillator.type = "square"

      // Envelope para hacer el sonido más musical
      gainNode.gain.setValueAtTime(0, audioContext.currentTime)
      gainNode.gain.linearRampToValueAtTime(0.1, audioContext.currentTime + 0.01)
      gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.1)

      oscillator.start(audioContext.currentTime)
      oscillator.stop(audioContext.currentTime + 0.1)
    } catch (error) {
      console.log("Error playing metronome sound:", error)
    }
  }

  // Controlar el metrónomo
  useEffect(() => {
    if (isPlaying) {
      const interval = 60000 / bpm // Convertir BPM a milisegundos

      intervalRef.current = setInterval(() => {
        setBeat((prevBeat) => {
          const newBeat = (prevBeat + 1) % 4
          // Acento en el primer beat
          playClick(newBeat === 0)
          return newBeat
        })
      }, interval)
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
        intervalRef.current = null
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
      }
    }
  }, [isPlaying, bpm, isMuted])

  const togglePlay = () => {
    setIsPlaying(!isPlaying)
  }

  return (
    <div className={`fixed bottom-4 right-4 z-40 ${className}`}>
      {/* Panel de controles expandible */}
      {showControls && (
        <div className="absolute bottom-16 right-0 bg-white border border-primary/20 rounded-lg shadow-lg p-3 mb-2 min-w-[200px]">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium">BPM</span>
              <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">{bpm}</span>
            </div>

            <div className="flex gap-1">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setBpm(Math.max(40, bpm - 10))}
                className="h-7 px-2 text-xs"
              >
                -10
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setBpm(Math.max(40, bpm - 1))}
                className="h-7 px-2 text-xs"
              >
                -1
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setBpm(Math.min(200, bpm + 1))}
                className="h-7 px-2 text-xs"
              >
                +1
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setBpm(Math.min(200, bpm + 10))}
                className="h-7 px-2 text-xs"
              >
                +10
              </Button>
            </div>

            <div className="grid grid-cols-2 gap-1">
              <Button variant="outline" size="sm" onClick={() => setBpm(90)} className="h-7 text-xs">
                Lento 90
              </Button>
              <Button variant="outline" size="sm" onClick={() => setBpm(120)} className="h-7 text-xs">
                Normal 120
              </Button>
            </div>

            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsMuted(!isMuted)}
              className={`w-full h-7 text-xs ${isMuted ? "bg-red-50 text-red-600" : ""}`}
            >
              {isMuted ? "Activar sonido" : "Silenciar"}
            </Button>
          </div>
        </div>
      )}

      {/* Widget compacto principal */}
      <div className="bg-white border border-primary/20 rounded-lg shadow-lg p-2">
        <div className="flex items-center gap-2">
          {/* Cuatro puntos indicadores */}
          <div className="flex gap-1">
            {[0, 1, 2, 3].map((i) => (
              <div
                key={i}
                className={`w-2 h-2 rounded-full transition-all duration-100 ${
                  isPlaying && beat === i
                    ? i === 0
                      ? "bg-accent scale-125 shadow-sm"
                      : "bg-primary scale-110"
                    : "bg-gray-300"
                }`}
              />
            ))}
          </div>

          {/* Botón play/pause */}
          <Button
            onClick={togglePlay}
            size="sm"
            className={`h-8 w-8 p-0 transition-all duration-300 ${
              isPlaying ? "bg-red-500 hover:bg-red-600" : "bg-primary hover:bg-primary/90"
            }`}
          >
            {isPlaying ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
          </Button>

          {/* Botón de configuración */}
          <Button
            onClick={() => setShowControls(!showControls)}
            variant="ghost"
            size="sm"
            className="h-8 w-8 p-0 text-gray-500 hover:text-primary"
          >
            <Settings className="w-3 h-3" />
          </Button>
        </div>

        {/* BPM indicator muy pequeño */}
        <div className="text-center mt-1">
          <span className="text-xs text-gray-500">{bpm}</span>
        </div>
      </div>
    </div>
  )
}
