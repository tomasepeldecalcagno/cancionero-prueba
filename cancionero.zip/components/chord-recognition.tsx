"use client"

// Utilidad para reconocimiento avanzado de acordes
export class ChordRecognition {
  /**
   * Detecta si una línea contiene principalmente acordes
   */
  static isChordLine(line: string): boolean {
    const trimmedLine = line.trim()
    if (!trimmedLine) return false

    // Dividir en palabras
    const words = trimmedLine.split(/\s+/)
    if (words.length === 0) return false

    // Contar cuántas palabras son acordes válidos
    let chordCount = 0
    const totalWords = words.length

    for (const word of words) {
      const cleanWord = word.replace(/[()[\]{}]/g, "").trim()
      if (this.isValidChord(cleanWord)) {
        chordCount++
      }
    }

    // Criterios para considerar una línea como línea de acordes:
    const chordRatio = chordCount / totalWords
    const hasLongWords = words.some((word) => word.length > 10)
    const hasCommonLyricWords = this.hasCommonLyricWords(trimmedLine)

    // Si hay muchos acordes válidos, es probable que sea línea de acordes
    if (chordCount >= 2 && chordRatio >= 0.5) return true

    // Si toda la línea son acordes válidos
    if (chordRatio === 1.0 && totalWords <= 8) return true

    return (
      chordRatio >= 0.4 && // Reducir umbral a 40%
      !hasLongWords && // No tiene palabras muy largas
      !hasCommonLyricWords && // No contiene palabras típicas de letra
      totalWords <= 15 // Aumentar límite de palabras
    )
  }

  /**
   * Valida si una palabra es un acorde válido
   */
  static isValidChord(word: string): boolean {
    if (!word || word.length > 12) return false

    // Limpiar caracteres especiales al inicio y final
    const cleanWord = word.replace(/^[^\w#b♯♭]+|[^\w#b♯♭/]+$/g, "")

    // Patrones de acordes más específicos incluyendo inversiones
    const chordPatterns = [
      // Inglés básico
      /^[A-G][#b♯♭]?$/,
      // Inglés con sufijos
      /^[A-G][#b♯♭]?(m|maj|min|dim|aug|sus[24]?|add[0-9]+|M?[0-9]+|[+°]|7)$/,
      // Inglés con slash (inversiones)
      /^[A-G][#b♯♭]?(m|maj|min|dim|aug|sus[24]?|add[0-9]+|M?[0-9]+|[+°]|7)?\/[A-G][#b♯♭]?$/,

      // Español básico (mayúsculas)
      /^(DO|RE|MI|FA|SOL|LA|SI)[#b♯♭]?$/,
      // Español con sufijos (mayúsculas)
      /^(DO|RE|MI|FA|SOL|LA|SI)[#b♯♭]?(m|maj|min|dim|aug|sus[24]?|add[0-9]+|M?[0-9]+|[+°]|7)$/,
      // Español con slash (inversiones)
      /^(DO|RE|MI|FA|SOL|LA|SI)[#b♯♭]?(m|maj|min|dim|aug|sus[24]?|add[0-9]+|M?[0-9]+|[+°]|7)?\/[A-G#b♯♭]+$/,

      // Español básico (minúsculas)
      /^(Do|Re|Mi|Fa|Sol|La|Si)[#b♯♭]?$/,
      // Español con sufijos (minúsculas)
      /^(Do|Re|Mi|Fa|Sol|La|Si)[#b♯♭]?(m|maj|min|dim|aug|sus[24]?|add[0-9]+|M?[0-9]+|[+°]|7)$/,
      // Español con inversiones (minúsculas)
      /^(Do|Re|Mi|Fa|Sol|La|Si)[#b♯♭]?(m|maj|min|dim|aug|sus[24]?|add[0-9]+|M?[0-9]+|[+°]|7)?\/[A-G#b♯♭]+$/,
    ]

    return chordPatterns.some((pattern) => pattern.test(cleanWord))
  }

  /**
   * Extrae todos los acordes de una línea
   */
  static extractChords(line: string): Array<{ chord: string; position: number; length: number }> {
    const chords: Array<{ chord: string; position: number; length: number }> = []
    const words = line.split(/(\s+)/)
    let position = 0

    for (const word of words) {
      if (word.trim() && this.isValidChord(word.trim())) {
        chords.push({
          chord: word.trim(),
          position: position,
          length: word.length,
        })
      }
      position += word.length
    }

    return chords
  }

  /**
   * Detecta palabras comunes de letras que no deberían ser acordes
   */
  private static hasCommonLyricWords(line: string): boolean {
    const commonWords = [
      // Español
      "que",
      "con",
      "una",
      "para",
      "por",
      "como",
      "pero",
      "todo",
      "cuando",
      "donde",
      "porque",
      "hasta",
      "desde",
      "sobre",
      "entre",
      "durante",
      "contra",
      "hacia",
      "amor",
      "vida",
      "tiempo",
      "mundo",
      "casa",
      "agua",
      "fuego",
      "tierra",
      "cielo",
      "corazón",
      "alma",
      "mente",
      "cuerpo",
      "mano",
      "ojo",
      "boca",
      "palabra",
      "canción",
      "música",
      "baile",
      "fiesta",
      "alegría",
      "tristeza",
      "dolor",
      "este",
      "esta",
      "estos",
      "estas",
      "aquel",
      "aquella",
      "muy",
      "más",
      "menos",
      "tanto",
      "tan",
      "también",
      "tampoco",
      "siempre",
      "nunca",
      "eres",
      "soy",
      "es",
      "son",
      "somos",
      "está",
      "están",
      "estoy",
      "estás",
      "tiene",
      "tengo",
      "tienes",

      // Inglés
      "the",
      "and",
      "you",
      "that",
      "was",
      "for",
      "are",
      "with",
      "his",
      "they",
      "have",
      "this",
      "will",
      "your",
      "from",
      "know",
      "want",
      "been",
      "good",
      "much",
      "some",
      "time",
      "very",
      "when",
      "come",
      "here",
      "just",
      "like",
      "long",
      "make",
      "many",
      "over",
      "such",
      "take",
      "than",
      "them",
      "well",
      "were",
      "love",
      "life",
      "heart",
      "soul",
      "mind",
      "body",
      "hand",
      "song",
      "music",
      "dance",
      "party",
      "happy",
      "sad",
      "pain",
      "always",
      "never",
      "sometimes",
      "maybe",
      "could",
      "would",
      "should",
      "might",
    ]

    const lowerLine = line.toLowerCase()
    return commonWords.some((word) => {
      const regex = new RegExp(`\\b${word}\\b`, "i")
      return regex.test(lowerLine)
    })
  }

  /**
   * Analiza toda la letra y separa líneas de acordes de líneas de letra
   */
  static analyzeLyrics(lyrics: string): {
    lines: Array<{
      content: string
      type: "chord" | "lyric" | "empty"
      chords?: Array<{ chord: string; position: number; length: number }>
    }>
    detectedKey: string
    allChords: string[]
  } {
    const lines = lyrics.split("\n")
    const result = []
    const allChords: string[] = []

    for (const line of lines) {
      if (line.trim() === "") {
        result.push({ content: line, type: "empty" as const })
        continue
      }

      if (this.isChordLine(line)) {
        const chords = this.extractChords(line)
        chords.forEach((c) => allChords.push(c.chord))

        result.push({
          content: line,
          type: "chord" as const,
          chords: chords,
        })
      } else {
        result.push({
          content: line,
          type: "lyric" as const,
        })
      }
    }

    const detectedKey = this.detectKey(allChords)

    console.log(`🎵 Chord Recognition Analysis:`)
    console.log(`   All chords found: ${allChords.join(", ")}`)
    console.log(`   Detected key: ${detectedKey}`)

    return {
      lines: result,
      detectedKey,
      allChords: [...new Set(allChords)], // Eliminar duplicados
    }
  }

  /**
   * ✅ DETECCIÓN DE TONALIDAD MEJORADA CON ANÁLISIS ARMÓNICO
   */
  private static detectKey(chords: string[]): string {
    if (chords.length === 0) return "C"

    console.log(`🔍 Detecting key from chords: ${chords.join(", ")}`)

    // Contar frecuencia de cada acorde
    const chordFrequency: { [key: string]: number } = {}
    const rootFrequency: { [key: string]: number } = {}

    chords.forEach((chord) => {
      const root = this.getChordRoot(chord)
      chordFrequency[chord] = (chordFrequency[chord] || 0) + 1
      rootFrequency[root] = (rootFrequency[root] || 0) + 1
    })

    console.log(`   Chord frequency:`, chordFrequency)
    console.log(`   Root frequency:`, rootFrequency)

    // ✅ ANÁLISIS ARMÓNICO MEJORADO
    const possibleKeys = this.analyzeHarmonicContext(chords)
    console.log(`   Possible keys from harmonic analysis:`, possibleKeys)

    if (possibleKeys.length > 0) {
      const detectedKey = possibleKeys[0]
      console.log(`   Key detected by harmonic analysis: ${detectedKey}`)
      return detectedKey
    }

    // Fallback: usar el acorde más frecuente
    const roots = Object.keys(rootFrequency).sort((a, b) => rootFrequency[b] - rootFrequency[a])
    const mostFrequentRoot = roots[0]

    // Verificar si hay acordes menores para determinar si es tonalidad menor
    const firstChordIsMinor = chords.length > 0 && this.isMinorChord(chords[0])

    if (firstChordIsMinor) {
      const firstRoot = this.getChordRoot(chords[0])
      const detectedKey = firstRoot + "m"
      console.log(`   First chord is minor (${chords[0]}), detected key: ${detectedKey}`)
      return detectedKey
    }

    const detectedKey = mostFrequentRoot
    console.log(`   Most frequent root: ${mostFrequentRoot}, detected key: ${detectedKey}`)

    return detectedKey
  }

  /**
   * ✅ ANÁLISIS ARMÓNICO PARA DETECTAR TONALIDAD
   */
  private static analyzeHarmonicContext(chords: string[]): string[] {
    const possibleKeys: { key: string; score: number; reasons: string[] }[] = []

    // Definir progresiones armónicas más específicas
    const keyAnalysis = [
      // Tonalidades mayores con acordes característicos
      {
        key: "C",
        primary: ["C", "F", "G"],
        secondary: ["Am", "Dm", "Em"],
        dominant: "G",
        subdominant: "F",
      },
      {
        key: "G",
        primary: ["G", "C", "D"],
        secondary: ["Em", "Am", "Bm"],
        dominant: "D",
        subdominant: "C",
      },
      {
        key: "D",
        primary: ["D", "G", "A"],
        secondary: ["Bm", "Em", "F#m"],
        dominant: "A",
        subdominant: "G",
      },
      {
        key: "A",
        primary: ["A", "D", "E"],
        secondary: ["F#m", "Bm", "C#m"],
        dominant: "E",
        subdominant: "D",
      },
      {
        key: "E",
        primary: ["E", "A", "B"],
        secondary: ["C#m", "F#m", "G#m"],
        dominant: "B",
        subdominant: "A",
      },
      {
        key: "B",
        primary: ["B", "E", "F#"],
        secondary: ["G#m", "C#m", "D#m"],
        dominant: "F#",
        subdominant: "E",
      },
      {
        key: "F#",
        primary: ["F#", "B", "C#"],
        secondary: ["D#m", "G#m", "A#m"],
        dominant: "C#",
        subdominant: "B",
      },
      {
        key: "F",
        primary: ["F", "Bb", "C"],
        secondary: ["Dm", "Gm", "Am"],
        dominant: "C",
        subdominant: "Bb",
      },
      {
        key: "Bb",
        primary: ["Bb", "Eb", "F"],
        secondary: ["Gm", "Cm", "Dm"],
        dominant: "F",
        subdominant: "Eb",
      },
      {
        key: "Eb",
        primary: ["Eb", "Ab", "Bb"],
        secondary: ["Cm", "Fm", "Gm"],
        dominant: "Bb",
        subdominant: "Ab",
      },
      {
        key: "Ab",
        primary: ["Ab", "Db", "Eb"],
        secondary: ["Fm", "Bbm", "Cm"],
        dominant: "Eb",
        subdominant: "Db",
      },
      {
        key: "Db",
        primary: ["Db", "Gb", "Ab"],
        secondary: ["Bbm", "Ebm", "Fm"],
        dominant: "Ab",
        subdominant: "Gb",
      },

      // Tonalidades menores
      {
        key: "Am",
        primary: ["Am", "Dm", "Em"],
        secondary: ["F", "G", "C"],
        dominant: "Em",
        subdominant: "Dm",
      },
      {
        key: "Em",
        primary: ["Em", "Am", "Bm"],
        secondary: ["C", "D", "G"],
        dominant: "Bm",
        subdominant: "Am",
      },
      {
        key: "Bm",
        primary: ["Bm", "Em", "F#m"],
        secondary: ["G", "A", "D"],
        dominant: "F#m",
        subdominant: "Em",
      },
      {
        key: "F#m",
        primary: ["F#m", "Bm", "C#m"],
        secondary: ["D", "E", "A"],
        dominant: "C#m",
        subdominant: "Bm",
      },
      {
        key: "C#m",
        primary: ["C#m", "F#m", "G#m"],
        secondary: ["A", "B", "E"],
        dominant: "G#m",
        subdominant: "F#m",
      },
      {
        key: "G#m",
        primary: ["G#m", "C#m", "D#m"],
        secondary: ["E", "F#", "B"],
        dominant: "D#m",
        subdominant: "C#m",
      },
      {
        key: "D#m",
        primary: ["D#m", "G#m", "A#m"],
        secondary: ["B", "C#", "F#"],
        dominant: "A#m",
        subdominant: "G#m",
      },
      {
        key: "Dm",
        primary: ["Dm", "Gm", "Am"],
        secondary: ["Bb", "C", "F"],
        dominant: "Am",
        subdominant: "Gm",
      },
      {
        key: "Gm",
        primary: ["Gm", "Cm", "Dm"],
        secondary: ["Eb", "F", "Bb"],
        dominant: "Dm",
        subdominant: "Cm",
      },
      {
        key: "Cm",
        primary: ["Cm", "Fm", "Gm"],
        secondary: ["Ab", "Bb", "Eb"],
        dominant: "Gm",
        subdominant: "Fm",
      },
      {
        key: "Fm",
        primary: ["Fm", "Bbm", "Cm"],
        secondary: ["Db", "Eb", "Ab"],
        dominant: "Cm",
        subdominant: "Bbm",
      },
      {
        key: "Bbm",
        primary: ["Bbm", "Ebm", "Fm"],
        secondary: ["Gb", "Ab", "Db"],
        dominant: "Fm",
        subdominant: "Ebm",
      },
    ]

    // Obtener raíces de los acordes de la canción
    const songRoots = chords.map((chord) => this.getChordRoot(chord))
    const songChordsWithSuffix = chords.map((chord) => {
      const parsed = this.parseChord(chord)
      return parsed.root + (parsed.suffix.includes("m") && !parsed.suffix.includes("maj") ? "m" : "")
    })

    console.log(`   Song roots: ${songRoots.join(", ")}`)
    console.log(`   Song chords with suffix: ${songChordsWithSuffix.join(", ")}`)

    // Calcular puntuación para cada tonalidad posible
    keyAnalysis.forEach((analysis) => {
      let score = 0
      const reasons: string[] = []

      // 1. Verificar si la tónica está presente (muy importante)
      const tonicRoot = analysis.key.replace("m", "")
      if (songRoots.includes(tonicRoot)) {
        score += 10
        reasons.push(`Tónica ${tonicRoot} presente`)
      }

      // 2. Verificar acordes primarios (I, IV, V)
      let primaryMatches = 0
      analysis.primary.forEach((primaryChord) => {
        if (songChordsWithSuffix.includes(primaryChord)) {
          score += 8
          primaryMatches++
          reasons.push(`Acorde primario ${primaryChord}`)
        }
      })

      // 3. Verificar acordes secundarios
      analysis.secondary.forEach((secondaryChord) => {
        if (songChordsWithSuffix.includes(secondaryChord)) {
          score += 4
          reasons.push(`Acorde secundario ${secondaryChord}`)
        }
      })

      // 4. Verificar dominante (muy característico)
      if (songRoots.includes(analysis.dominant.replace("m", ""))) {
        score += 6
        reasons.push(`Dominante ${analysis.dominant}`)
      }

      // 5. Verificar subdominante
      if (songRoots.includes(analysis.subdominant.replace("m", ""))) {
        score += 5
        reasons.push(`Subdominante ${analysis.subdominant}`)
      }

      // 6. Bonus por el primer acorde
      if (chords.length > 0) {
        const firstChordRoot = this.getChordRoot(chords[0])
        const firstChordWithSuffix = songChordsWithSuffix[0]

        if (firstChordRoot === tonicRoot) {
          score += 15
          reasons.push(`Primer acorde es tónica`)
        }

        if (firstChordWithSuffix === analysis.key) {
          score += 20
          reasons.push(`Primer acorde coincide exactamente con tonalidad`)
        }
      }

      // 7. Penalizar si faltan acordes primarios importantes
      if (primaryMatches === 0) {
        score -= 5
        reasons.push(`Sin acordes primarios`)
      }

      // 8. Bonus por progresiones típicas
      if (
        songChordsWithSuffix.includes(analysis.key) &&
        songChordsWithSuffix.includes(analysis.subdominant) &&
        songChordsWithSuffix.includes(analysis.dominant.replace("m", ""))
      ) {
        score += 10
        reasons.push(`Progresión I-IV-V completa`)
      }

      if (score > 0) {
        possibleKeys.push({ key: analysis.key, score, reasons })
      }
    })

    // Ordenar por puntuación y mostrar análisis detallado
    const sortedKeys = possibleKeys.sort((a, b) => b.score - a.score)

    console.log(`   Detailed key analysis:`)
    sortedKeys.slice(0, 5).forEach((keyData, index) => {
      console.log(`     ${index + 1}. ${keyData.key}: ${keyData.score} points`)
      console.log(`        Reasons: ${keyData.reasons.join(", ")}`)
    })

    return sortedKeys.slice(0, 3).map((k) => k.key)
  }

  /**
   * ✅ EXTRACCIÓN DE RAÍZ MEJORADA
   */
  private static getChordRoot(chord: string): string {
    // Regex mejorado para extraer la raíz del acorde
    const match = chord.match(/^(DO|RE|MI|FA|SOL|LA|SI|Do|Re|Mi|Fa|Sol|La|Si|do|re|mi|fa|sol|la|si|[A-G])([#b♯♭]?)/)
    if (!match) return "C"

    const [, noteBase, accidental] = match
    const fullNote = noteBase + (accidental || "")

    // Mapeo a notación estándar
    const noteMap: { [key: string]: string } = {
      // Inglés
      C: "C",
      "C#": "C#",
      Db: "C#",
      D: "D",
      "D#": "D#",
      Eb: "D#",
      E: "E",
      F: "F",
      "F#": "F#",
      Gb: "F#",
      G: "G",
      "G#": "G#",
      Ab: "G#",
      A: "A",
      "A#": "A#",
      Bb: "A#",
      B: "B",

      // Español mayúscula
      DO: "C",
      "DO#": "C#",
      REB: "C#",
      RE: "D",
      "RE#": "D#",
      MIB: "D#",
      MI: "E",
      FA: "F",
      "FA#": "F#",
      SOLB: "F#",
      SOL: "G",
      "SOL#": "G#",
      LAB: "G#",
      LA: "A",
      "LA#": "A#",
      SIB: "A#",
      SI: "B",

      // Español capitalizado
      Do: "C",
      "Do#": "C#",
      Reb: "C#",
      Re: "D",
      "Re#": "D#",
      Mib: "D#",
      Mi: "E",
      Fa: "F",
      "Fa#": "F#",
      Solb: "F#",
      Sol: "G",
      "Sol#": "G#",
      Lab: "G#",
      La: "A",
      "La#": "A#",
      Sib: "A#",
      Si: "B",

      // Minúsculas
      c: "C",
      "c#": "C#",
      db: "C#",
      d: "D",
      "d#": "D#",
      eb: "D#",
      e: "E",
      f: "F",
      "f#": "F#",
      gb: "F#",
      g: "G",
      "g#": "G#",
      ab: "G#",
      a: "A",
      "a#": "A#",
      bb: "A#",
      b: "B",
      do: "C",
      "do#": "C#",
      reb: "C#",
      re: "D",
      "re#": "D#",
      mib: "D#",
      mi: "E",
      fa: "F",
      "fa#": "F#",
      solb: "F#",
      sol: "G",
      "sol#": "G#",
      lab: "G#",
      la: "A",
      "la#": "A#",
      sib: "A#",
      si: "B",
    }

    const standardRoot = noteMap[fullNote] || "C"
    console.log(`   Chord root: ${chord} → ${fullNote} → ${standardRoot}`)
    return standardRoot
  }

  /**
   * Determina si un acorde es menor
   */
  private static isMinorChord(chord: string): boolean {
    // Buscar indicadores de acorde menor
    return /m(?!aj|M)/.test(chord) || chord.includes("dim") || chord.includes("°")
  }

  /**
   * Genera ejemplos de formato correcto
   */
  static getFormatExamples(): {
    title: string
    description: string
    example: string
  }[] {
    return [
      {
        title: "Formato Básico",
        description: "Acordes en línea separada, letra debajo",
        example: `C       G       Am      F
Let it be, let it be, let it be
C       G       F       C
Whisper words of wisdom`,
      },
      {
        title: "Notación Española",
        description: "Usando nombres de notas en español",
        example: `RE      LA      MIm     SOL
Tú eres la luz que brilló en las tinieblas
RE      LA      SOL
Abrió mis ojos pude ver`,
      },
      {
        title: "Acordes con Extensiones e Inversiones",
        description: "Séptimas, novenas y acordes con bajo específico",
        example: `Cmaj7   G7      Am7     F6
Beautiful song with jazz chords
Dm7     G7      C/E     Am/C
Complex harmonies with inversions`,
      },
    ]
  }

  /**
   * Lista de notas cromáticas
   */
  static NOTE_TO_CHROMATIC: { [key: string]: string } = {
    // Inglés
    C: "C",
    "C#": "C#",
    Db: "C#",
    D: "D",
    "D#": "D#",
    Eb: "D#",
    E: "E",
    F: "F",
    "F#": "F#",
    Gb: "F#",
    G: "G",
    "G#": "G#",
    Ab: "G#",
    A: "A",
    "A#": "A#",
    Bb: "A#",
    B: "B",

    // Español mayúscula
    DO: "C",
    "DO#": "C#",
    REB: "C#",
    RE: "D",
    "RE#": "D#",
    MIB: "D#",
    MI: "E",
    FA: "F",
    "FA#": "F#",
    SOLB: "F#",
    SOL: "G",
    "SOL#": "G#",
    LAB: "G#",
    LA: "A",
    "LA#": "A#",
    SIB: "A#",
    SI: "B",

    // Español capitalizado
    Do: "C",
    "Do#": "C#",
    Reb: "C#",
    Re: "D",
    "Re#": "D#",
    Mib: "D#",
    Mi: "E",
    Fa: "F",
    "Fa#": "F#",
    Solb: "F#",
    Sol: "G",
    "Sol#": "G#",
    Lab: "G#",
    La: "A",
    "La#": "A#",
    Sib: "A#",
    Si: "B",

    // Minúsculas
    c: "C",
    "c#": "C#",
    db: "C#",
    d: "D",
    "d#": "D#",
    eb: "D#",
    e: "E",
    f: "F",
    "f#": "F#",
    gb: "F#",
    g: "G",
    "g#": "G#",
    ab: "G#",
    a: "A",
    "a#": "A#",
    bb: "A#",
    b: "B",
    do: "C",
    "do#": "C#",
    reb: "C#",
    re: "D",
    "re#": "D#",
    mib: "D#",
    mi: "E",
    fa: "F",
    "fa#": "F#",
    solb: "F#",
    sol: "G",
    "sol#": "G#",
    lab: "G#",
    la: "A",
    "la#": "A#",
    sib: "A#",
    si: "B",
  }

  /**
   * Análisis de acorde corregido con mejor detección de acordes menores
   */
  static parseChord(
    chord: string,
    songFormat?: { isSpanish: boolean; caseStyle: "upper" | "lower" | "title" },
  ): {
    root: string
    suffix: string
    bassNote?: string
    originalRoot: string
    originalBass?: string
    isSpanish: boolean
    caseStyle: "upper" | "lower" | "title"
  } {
    const parts = chord.split("/")
    const mainChord = parts[0].trim()
    const bassNote = parts[1]?.trim()

    const match = mainChord.match(
      /^(DO|RE|MI|FA|SOL|LA|SI|Do|Re|Mi|Fa|Sol|La|Si|do|re|mi|fa|sol|la|si|[A-G])([#b♯♭]?)(.*)$/i,
    )

    if (!match) {
      return {
        root: "C",
        suffix: "",
        originalRoot: chord,
        isSpanish: songFormat?.isSpanish || false,
        caseStyle: songFormat?.caseStyle || "upper",
      }
    }

    const [, noteBase, accidental, suffix] = match
    const fullNote = noteBase + accidental
    const chromaticRoot = this.NOTE_TO_CHROMATIC[fullNote] || "C"

    let isSpanish: boolean
    let caseStyle: "upper" | "lower" | "title"

    if (songFormat) {
      isSpanish = songFormat.isSpanish
      caseStyle = songFormat.caseStyle
    } else {
      isSpanish = /^(DO|RE|MI|FA|SOL|LA|SI|Do|Re|Mi|Fa|Sol|La|Si|do|re|mi|fa|sol|la|si)/i.test(noteBase)
      caseStyle =
        fullNote === fullNote.toUpperCase() ? "upper" : fullNote === fullNote.toLowerCase() ? "lower" : "title"
    }

    let chromaticBass: string | undefined
    let originalBass: string | undefined

    if (bassNote) {
      originalBass = bassNote
      chromaticBass = this.NOTE_TO_CHROMATIC[bassNote] || bassNote
    }

    return {
      root: chromaticRoot,
      suffix: suffix,
      bassNote: chromaticBass,
      originalRoot: fullNote,
      originalBass: originalBass,
      isSpanish: isSpanish,
      caseStyle: caseStyle,
    }
  }
}

export default ChordRecognition
