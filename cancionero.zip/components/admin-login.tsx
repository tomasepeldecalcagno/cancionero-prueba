"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Lock, LogIn, Eye, EyeOff, AlertCircle, Wifi, WifiOff } from 'lucide-react'
import { isSupabaseConfigured } from "@/lib/supabase"

interface AdminLoginProps {
  onSuccess: () => void
  onCancel: () => void
  onLogin: (email: string, password: string) => Promise<boolean>
}

export default function AdminLogin({ onSuccess, onCancel, onLogin }: AdminLoginProps) {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    try {
      console.log('🔐 Attempting login from component...')
      const success = await onLogin(email, password)
      if (success) {
        console.log('✅ Login successful, calling onSuccess')
        onSuccess()
      }
    } catch (error: any) {
      console.error('❌ Login failed:', error)
      setError(error.message || "Error al iniciar sesión")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/20 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-md border border-contemplative/20 shadow-lg bg-white/95 backdrop-blur-sm">
        <CardHeader className="text-center">
          <div className="w-12 h-12 bg-contemplative/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Lock className="w-6 h-6 text-contemplative" />
          </div>
          <CardTitle className="text-xl text-contemplative">Acceso de Administrador</CardTitle>
          
          {/* ✅ MOSTRAR ESTADO DE CONFIGURACIÓN */}
          <div className="flex justify-center mb-2">
            {isSupabaseConfigured ? (
              <div className="flex items-center gap-2 text-xs text-green-600 bg-green-50 px-3 py-1 rounded-full">
                <Wifi className="w-3 h-3" />
                Base de datos conectada
              </div>
            ) : (
              <div className="flex items-center gap-2 text-xs text-red-600 bg-red-50 px-3 py-1 rounded-full">
                <WifiOff className="w-3 h-3" />
                Base de datos no configurada
              </div>
            )}
          </div>
          
          <p className="text-sm text-muted-foreground">
            {isSupabaseConfigured 
              ? "Inicia sesión para crear, editar o eliminar canciones"
              : "La autenticación no está disponible sin configurar la base de datos"
            }
          </p>
        </CardHeader>
        
        <CardContent>
          {!isSupabaseConfigured ? (
            // ✅ MENSAJE CUANDO SUPABASE NO ESTÁ CONFIGURADO
            <div className="text-center space-y-4">
              <div className="flex items-center gap-2 text-sm text-amber-600 bg-amber-50 p-3 rounded-lg">
                <AlertCircle className="w-4 h-4" />
                <span>La base de datos no está configurada. Las canciones se guardarán localmente.</span>
              </div>
              <Button
                onClick={onCancel}
                className="w-full"
                variant="outline"
              >
                Entendido
              </Button>
            </div>
          ) : (
            // ✅ FORMULARIO DE LOGIN CUANDO SUPABASE ESTÁ CONFIGURADO
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Email"
                  className="border-contemplative/30 focus:border-contemplative/50"
                  required
                  disabled={isLoading}
                />
              </div>
              
              <div className="relative">
                <Input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Contraseña"
                  className="border-contemplative/30 focus:border-contemplative/50 pr-10"
                  required
                  disabled={isLoading}
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                  onClick={() => setShowPassword(!showPassword)}
                  disabled={isLoading}
                >
                  {showPassword ? (
                    <EyeOff className="w-4 h-4 text-muted-foreground" />
                  ) : (
                    <Eye className="w-4 h-4 text-muted-foreground" />
                  )}
                </Button>
              </div>

              {error && (
                <div className="flex items-center gap-2 text-sm text-red-600 bg-red-50 p-3 rounded-lg">
                  <AlertCircle className="w-4 h-4" />
                  <span>{error}</span>
                </div>
              )}

              <div className="flex gap-3">
                <Button
                  type="button"
                  variant="ghost"
                  onClick={onCancel}
                  className="flex-1"
                  disabled={isLoading}
                >
                  Cancelar
                </Button>
                <Button
                  type="submit"
                  className="flex-1 bg-contemplative hover:bg-contemplative/90"
                  disabled={isLoading || !email.trim() || !password.trim()}
                >
                  {isLoading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border border-white/30 border-t-white rounded-full animate-spin" />
                      Iniciando...
                    </div>
                  ) : (
                    <>
                      <LogIn className="w-4 h-4 mr-2" />
                      Iniciar Sesión
                    </>
                  )}
                </Button>
              </div>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
