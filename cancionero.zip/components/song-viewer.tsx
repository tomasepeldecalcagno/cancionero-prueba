"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  ArrowLeft,
  Edit,
  Trash2,
  Plus,
  Minus,
  RotateCcw,
  Music,
  Settings,
  Volume2,
  Play,
  Pause,
  SkipBack,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import ChordRecognition from "@/components/chord-recognition"
import MusicTheory from "@/components/music-theory"

interface Song {
  id: string
  title: string
  artist?: string
  lyrics: string
  original_key?: string
  audio_file?: string
  audio_file_name?: string
  category: "misa" | "general"
  created_at?: string
  updated_at?: string
}

interface SongViewerProps {
  song: Song
  onBack: () => void
  onEdit: () => void
  onDelete: () => void
}

interface ProcessedSection {
  type: "chord-lyric-pair" | "lyric-only" | "empty"
  chordLine?: string
  lyricLine?: string
  content?: string
}

export default function SongViewer({ song, onBack, onEdit, onDelete }: SongViewerProps) {
  const [selectedKey, setSelectedKey] = useState<string>("")
  const [fontSize, setFontSize] = useState<"small" | "medium" | "large">("medium")
  const [processedSections, setProcessedSections] = useState<ProcessedSection[]>([])
  const [isAutoScrolling, setIsAutoScrolling] = useState(false)
  const [scrollSpeed, setScrollSpeed] = useState(1.0) // 0.5x, 1.0x, 1.5x
  const [showAdvancedControls, setShowAdvancedControls] = useState(false)
  const [isMobile, setIsMobile] = useState(false)

  // Referencias para ambas vistas
  const normalScrollContainerRef = useRef<HTMLDivElement>(null)
  const autoScrollIntervalRef = useRef<NodeJS.Timeout | null>(null)

  const [availableKeys, setAvailableKeys] = useState<string[]>([])
  const [originalKey, setOriginalKey] = useState<string>("")
  const [songFormat, setSongFormat] = useState<{ isSpanish: boolean; caseStyle: "upper" | "lower" | "title" }>({
    isSpanish: false,
    caseStyle: "upper",
  })

  // 📱 DETECTAR MÓVIL
  useEffect(() => {
    const checkMobile = () => {
      const mobile = window.innerWidth <= 768
      setIsMobile(mobile)
    }

    checkMobile()
    window.addEventListener("resize", checkMobile)
    return () => window.removeEventListener("resize", checkMobile)
  }, [])

  const detectOriginalKey = (lyrics: string): string => {
    try {
      const analysis = ChordRecognition.analyzeLyrics(lyrics)
      return analysis.detectedKey
    } catch (error) {
      console.error("Error detecting key:", error)
      return "C"
    }
  }

  const getValidKeys = (originalKey: string): string[] => {
    const commonKeys = MusicTheory.getCommonKeys()
    const keys: string[] = [originalKey]

    commonKeys.forEach((key) => {
      if (key !== originalKey) {
        keys.push(key)
      }
    })

    const circleOfFifths = ["C", "G", "D", "A", "E", "B", "F#", "C#", "F", "Bb", "Eb", "Ab"]

    return keys.sort((a, b) => {
      if (a === originalKey) return -1
      if (b === originalKey) return 1

      const aRoot = MusicTheory.parseChord(a).root
      const bRoot = MusicTheory.parseChord(b).root
      const aIndex = circleOfFifths.indexOf(aRoot)
      const bIndex = circleOfFifths.indexOf(bRoot)

      return (aIndex === -1 ? 999 : aIndex) - (bIndex === -1 ? 999 : bIndex)
    })
  }

  // 🎵 VELOCIDADES OPTIMIZADAS PARA MÚSICOS - VERSIÓN ROBUSTA
  const getScrollConfiguration = () => {
    // Velocidades base MUCHO más bajas para lectura cómoda
    const baseSpeed = isMobile ? 30 : 40 // Aumentado un poco para asegurar movimiento visible

    const speedConfig = {
      pixelsPerSecond: baseSpeed * scrollSpeed,
      updateInterval: scrollSpeed < 0.5 ? 100 : 50, // Intervalos más largos para velocidades muy lentas
    }

    const pixelsPerFrame = speedConfig.pixelsPerSecond / (1000 / speedConfig.updateInterval)

    return {
      pixelsPerFrame: Math.max(1, Math.round(pixelsPerFrame)), // Asegurar mínimo 1px y redondear
      updateInterval: speedConfig.updateInterval,
    }
  }

  // 🎵 AUTO-SCROLL MEJORADO Y MÁS ROBUSTO
  useEffect(() => {
    // Limpiar interval anterior
    if (autoScrollIntervalRef.current) {
      clearInterval(autoScrollIntervalRef.current)
      autoScrollIntervalRef.current = null
    }

    if (isAutoScrolling) {
      const config = getScrollConfiguration()

      console.log("🎵 Starting auto-scroll with config:", config)

      autoScrollIntervalRef.current = setInterval(() => {
        const container = normalScrollContainerRef.current

        if (!container) {
          console.warn("🎵 Container not found, stopping auto-scroll")
          setIsAutoScrolling(false)
          return
        }

        const currentScroll = container.scrollTop
        const maxScroll = container.scrollHeight - container.clientHeight

        console.log("🎵 Scroll info:", { currentScroll, maxScroll, pixelsPerFrame: config.pixelsPerFrame })

        // Verificar si llegamos al final
        if (currentScroll >= maxScroll - 5) {
          // 5px de margen
          console.log("🎵 Reached end, stopping auto-scroll")
          setIsAutoScrolling(false)
          return
        }

        // Hacer scroll
        const newScrollTop = currentScroll + config.pixelsPerFrame
        container.scrollTop = newScrollTop

        console.log("🎵 Scrolled to:", newScrollTop)
      }, config.updateInterval)

      console.log("🎵 Auto-scroll interval started:", autoScrollIntervalRef.current)
    }

    return () => {
      if (autoScrollIntervalRef.current) {
        console.log("🎵 Cleaning up auto-scroll interval")
        clearInterval(autoScrollIntervalRef.current)
        autoScrollIntervalRef.current = null
      }
    }
  }, [isAutoScrolling, scrollSpeed, isMobile])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (autoScrollIntervalRef.current) {
        clearInterval(autoScrollIntervalRef.current)
      }
    }
  }, [])

  const toggleAutoScroll = () => {
    console.log("🎵 Toggle auto-scroll:", !isAutoScrolling)
    setIsAutoScrolling(!isAutoScrolling)
  }

  const resetScroll = () => {
    console.log("🎵 Reset scroll")
    setIsAutoScrolling(false)
    const container = normalScrollContainerRef.current
    if (container) {
      container.scrollTop = 0
      console.log("🎵 Scroll reset to top")
    }
  }

  const getSpeedLabel = (speed: number): string => {
    return `${speed.toFixed(1)}x`
  }

  // 🎵 SOLO 3 PRESETS PARA MÚSICOS
  const speedPresets = [
    {
      label: "x0.3",
      value: 0.3,
      description: "Muy lento - Para lectura detallada",
    },
    {
      label: "x0.6",
      value: 0.6,
      description: "Lento - Para canciones lentas",
    },
    {
      label: "x1.0",
      value: 1.0,
      description: "Normal - Tempo estándar",
    },
  ]

  useEffect(() => {
    const detectedFormat = MusicTheory.detectSongFormat(song.lyrics)
    setSongFormat(detectedFormat)

    const detectedKey = detectOriginalKey(song.lyrics)
    setOriginalKey(detectedKey)
    setAvailableKeys(getValidKeys(detectedKey))
    setSelectedKey(detectedKey)
    setProcessedSections(processLyricsIntoSections(song.lyrics, 0, detectedFormat, detectedKey))
  }, [song.lyrics])

  useEffect(() => {
    if (!selectedKey || !originalKey) return

    const semitones = MusicTheory.calculateSemitones(originalKey, selectedKey)
    setProcessedSections(processLyricsIntoSections(song.lyrics, semitones, songFormat, selectedKey))
  }, [selectedKey, originalKey, songFormat])

  const fontSizeClasses = {
    small: {
      chord: "text-[9px] sm:text-[10px] leading-none",
      lyric: "text-[10px] sm:text-xs leading-tight",
    },
    medium: {
      chord: "text-[10px] sm:text-xs leading-none",
      lyric: "text-xs sm:text-sm leading-tight",
    },
    large: {
      chord: "text-xs sm:text-sm leading-none",
      lyric: "text-sm sm:text-base leading-normal",
    },
  }

  const processLyricsIntoSections = (
    lyrics: string,
    semitones: number,
    format: { isSpanish: boolean; caseStyle: "upper" | "lower" | "title" },
    targetKey: string,
  ): ProcessedSection[] => {
    try {
      const analysis = ChordRecognition.analyzeLyrics(lyrics)
      const sections: ProcessedSection[] = []

      for (let i = 0; i < analysis.lines.length; i++) {
        const currentLine = analysis.lines[i]
        const nextLine = analysis.lines[i + 1]

        if (currentLine.type === "empty") {
          sections.push({
            type: "empty",
            content: currentLine.content,
          })
        } else if (currentLine.type === "chord" && nextLine && nextLine.type === "lyric") {
          let processedChordLine = currentLine.content

          if (currentLine.chords && semitones !== 0) {
            processedChordLine = transposeChordLineByPosition(
              currentLine.content,
              currentLine.chords,
              semitones,
              format,
              targetKey,
            )
          }

          sections.push({
            type: "chord-lyric-pair",
            chordLine: processedChordLine,
            lyricLine: nextLine.content,
          })

          i++
        } else if (currentLine.type === "lyric") {
          sections.push({
            type: "lyric-only",
            content: currentLine.content,
          })
        } else if (currentLine.type === "chord") {
          let processedChordLine = currentLine.content

          if (currentLine.chords && semitones !== 0) {
            processedChordLine = transposeChordLineByPosition(
              currentLine.content,
              currentLine.chords,
              semitones,
              format,
              targetKey,
            )
          }

          sections.push({
            type: "lyric-only",
            content: processedChordLine,
          })
        }
      }

      return sections
    } catch (error) {
      console.error("Error processing lyrics:", error)
      return lyrics.split("\n").map((line) => ({
        type: "lyric-only" as const,
        content: line,
      }))
    }
  }

  const transposeChordLineByPosition = (
    originalLine: string,
    chords: Array<{ chord: string; position: number; length: number }>,
    semitones: number,
    format: { isSpanish: boolean; caseStyle: "upper" | "lower" | "title" },
    targetKey: string,
  ): string => {
    const replacements: Array<{
      position: number
      length: number
      originalChord: string
      newChord: string
    }> = []

    chords.forEach((chordData) => {
      const originalChord = chordData.chord
      const transposed = MusicTheory.transposeChord(originalChord, semitones, format, targetKey)

      if (MusicTheory.isValidChord(transposed) && transposed !== originalChord) {
        replacements.push({
          position: chordData.position,
          length: chordData.length,
          originalChord: originalChord,
          newChord: transposed,
        })
      }
    })

    replacements.sort((a, b) => b.position - a.position)

    let result = originalLine
    replacements.forEach((replacement) => {
      const before = result.substring(0, replacement.position)
      const after = result.substring(replacement.position + replacement.length)
      result = before + replacement.newChord + after
    })

    return result
  }

  const renderSection = (section: ProcessedSection, index: number) => {
    if (section.type === "empty") {
      return (
        <div key={index} className="h-4 sm:h-6">
          &nbsp;
        </div>
      )
    }

    if (section.type === "chord-lyric-pair") {
      return (
        <div key={index} className="mb-3 sm:mb-4">
          <div
            className={`${fontSizeClasses[fontSize].chord} text-accent font-bold tracking-wider mb-0.5 sm:mb-1`}
            style={{
              fontFamily:
                'ui-monospace, SFMono-Regular, "SF Mono", Monaco, Consolas, "Liberation Mono", "Courier New", monospace',
              whiteSpace: "pre",
              minHeight: "12px",
            }}
          >
            {section.chordLine || "\u00A0"}
          </div>
          <div
            className={`${fontSizeClasses[fontSize].lyric} text-foreground`}
            style={{
              fontFamily:
                'ui-monospace, SFMono-Regular, "SF Mono", Monaco, Consolas, "Liberation Mono", "Courier New", monospace',
              whiteSpace: "pre-wrap",
              minHeight: "14px",
            }}
          >
            {section.lyricLine || "\u00A0"}
          </div>
        </div>
      )
    }

    if (section.type === "lyric-only") {
      const isChordLine = /^[A-G#b♯♭DOREMIFASOLLASIdomifasollasirem\s/0-9maj7dim+°aug-]+$/i.test(
        section.content?.trim() || "",
      )

      return (
        <div
          key={index}
          className={`mb-2 sm:mb-3 ${
            isChordLine
              ? `${fontSizeClasses[fontSize].chord} text-accent font-bold tracking-wider`
              : `${fontSizeClasses[fontSize].lyric} text-foreground`
          }`}
          style={{
            fontFamily:
              'ui-monospace, SFMono-Regular, "SF Mono", Monaco, Consolas, "Liberation Mono", "Courier New", monospace',
            whiteSpace: "pre-wrap",
            minHeight: isChordLine ? "12px" : "14px",
          }}
        >
          {section.content || "\u00A0"}
        </div>
      )
    }

    return null
  }

  // Componente de controles de auto-scroll reutilizable
  const AutoScrollControls = ({ compact = false }: { compact?: boolean }) => (
    <div className={`flex items-center gap-2 ${compact ? "justify-center" : "justify-start"}`}>
      <Button
        variant="ghost"
        size="sm"
        onClick={resetScroll}
        className={`${compact ? "h-8 px-3" : "h-8 sm:h-10 px-3"} text-xs text-primary hover:text-accent hover:bg-accent/10 transition-all duration-300`}
      >
        <SkipBack className="w-3 h-3 mr-1" />
        {compact ? "Inicio" : "Al inicio"}
      </Button>

      <Button
        variant={isAutoScrolling ? "default" : "outline"}
        size="sm"
        onClick={toggleAutoScroll}
        className={`${compact ? "h-8 px-3" : "h-8 sm:h-10 px-4"} text-xs transition-all duration-300 ${
          isAutoScrolling
            ? "bg-green-600 hover:bg-green-700 text-white shadow-lg"
            : "text-primary hover:text-accent hover:bg-accent/10 border-2 border-primary/30"
        }`}
      >
        {isAutoScrolling ? (
          <>
            <Pause className="w-3 h-3 mr-1" />
            Pausar
          </>
        ) : (
          <>
            <Play className="w-3 h-3 mr-1" />
            Auto-Scroll
          </>
        )}
      </Button>

      {!compact && (
        <div className="text-center min-w-[60px]">
          <div className="text-xs text-muted-foreground">Velocidad</div>
          <Badge variant="secondary" className="text-xs bg-primary/10 text-primary font-mono">
            {getSpeedLabel(scrollSpeed)}
          </Badge>
        </div>
      )}

      <div className="flex items-center gap-1">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setScrollSpeed(Math.max(0.1, scrollSpeed - 0.1))} // Cambiar de 0.3 a 0.1
          className={`${compact ? "h-8 w-8" : "h-8 sm:h-10 w-8"} p-0 text-xs text-primary hover:text-accent hover:bg-accent/10`}
        >
          <Minus className="w-3 h-3" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setScrollSpeed(Math.min(3, scrollSpeed + 0.1))}
          className={`${compact ? "h-8 w-8" : "h-8 sm:h-10 w-8"} p-0 text-xs text-primary hover:text-accent hover:bg-accent/10`}
        >
          <Plus className="w-3 h-3" />
        </Button>
      </div>

      {compact && (
        <div className="text-xs text-muted-foreground min-w-[50px] text-center font-mono">
          {getSpeedLabel(scrollSpeed)}
        </div>
      )}
    </div>
  )

  const transpose = selectedKey ? MusicTheory.calculateSemitones(originalKey, selectedKey) : 0

  return (
    <>
      <div className="max-w-6xl mx-auto space-y-6 sm:space-y-8 px-3 sm:px-4 lg:px-6">
        <div className="flex flex-col gap-4 sm:gap-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <Button
              variant="ghost"
              onClick={onBack}
              className="p-2 sm:p-3 text-primary hover:text-accent hover:bg-accent/10 transition-all duration-300 w-full sm:w-auto justify-center sm:justify-start"
            >
              <ArrowLeft className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
              <span className="sm:hidden">Volver</span>
              <span className="hidden sm:inline">Volver</span>
            </Button>
            <div className="flex items-center gap-3 sm:gap-4 flex-1 min-w-0 w-full sm:w-auto">
              <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center shadow-lg flex-shrink-0">
                <Music className="w-5 h-5 sm:w-6 sm:h-6 text-background" />
              </div>
              <div className="flex-1 min-w-0">
                <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-primary truncate">{song.title}</h1>
                <div className="flex items-center gap-2 mt-2">
                  {song.audio_file && (
                    <Badge variant="outline" className="text-xs border-accent/50 text-accent bg-accent/10">
                      <Volume2 className="w-3 h-3 mr-1" />
                      Audio
                    </Badge>
                  )}
                  {isAutoScrolling && (
                    <Badge variant="secondary" className="text-xs bg-green-100 text-green-700 border-green-200">
                      <Play className="w-3 h-3 mr-1" />
                      Auto-Scroll {getSpeedLabel(scrollSpeed)}
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row gap-3">
            <Button
              variant="outline"
              onClick={onEdit}
              className="flex-1 sm:flex-none bg-gradient-to-r from-background to-muted/20 border-2 border-secondary/50 text-primary hover:text-accent hover:border-accent/50 transition-all duration-300 h-10 sm:h-auto text-sm sm:text-base"
            >
              <Edit className="w-4 h-4 mr-2" />
              Editar Canción
            </Button>
            <Button
              variant="outline"
              onClick={onDelete}
              className="flex-1 sm:flex-none bg-gradient-to-r from-background to-muted/20 border-2 border-secondary/50 text-primary hover:text-destructive hover:border-destructive/50 transition-all duration-300 h-10 sm:h-auto text-sm sm:text-base"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Eliminar Canción
            </Button>
          </div>
        </div>

        {song.audio_file && (
          <Card className="border-2 border-accent/30 shadow-xl bg-gradient-to-br from-accent/5 to-primary/5">
            <CardHeader className="px-4 sm:px-6 py-3 sm:py-4">
              <CardTitle className="text-base sm:text-lg text-primary flex items-center gap-2">
                <Volume2 className="w-4 h-4 sm:w-5 sm:h-5" />
                Reproductor de Audio
              </CardTitle>
            </CardHeader>
            <CardContent className="px-4 sm:px-6 pb-4 sm:pb-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4">
                <div className="flex-1 w-full">
                  <audio controls className="w-full h-10 sm:h-12 rounded-md" preload="metadata">
                    <source src={song.audio_file} type="audio/mpeg" />
                    <source src={song.audio_file} type="audio/wav" />
                    <source src={song.audio_file} type="audio/ogg" />
                    Tu navegador no soporta el elemento de audio.
                  </audio>
                </div>
                <div className="text-xs sm:text-sm text-muted-foreground truncate w-full sm:w-auto sm:max-w-xs">
                  {song.audio_file_name}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <Card className="border-2 border-secondary/30 shadow-xl bg-gradient-to-br from-background to-muted/10">
          <CardHeader className="px-4 sm:px-6 py-3 sm:py-4">
            <CardTitle className="text-base sm:text-lg text-primary flex items-center gap-2">
              <Settings className="w-4 h-4 sm:w-5 sm:h-5" />
              Ajustes de la Canción
            </CardTitle>
          </CardHeader>
          <CardContent className="px-4 sm:px-6 pb-4 sm:pb-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
              <div className="space-y-3">
                <label className="text-sm font-semibold text-foreground">Tonalidad</label>
                <div className="flex flex-col gap-3">
                  <Select value={selectedKey} onValueChange={setSelectedKey}>
                    <SelectTrigger className="w-full h-10 sm:h-12 border-2 border-secondary/50 focus:border-primary/50 transition-all duration-300 text-sm sm:text-base">
                      <SelectValue placeholder={originalKey} />
                    </SelectTrigger>
                    <SelectContent>
                      {availableKeys.map((key) => (
                        <SelectItem key={key} value={key}>
                          {key} {key.includes("m") ? "(menor)" : "(mayor)"}
                          {key === originalKey && " - Original"}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <div className="flex flex-wrap items-center gap-2 text-xs sm:text-sm text-muted-foreground">
                    <span>
                      Original:{" "}
                      <Badge variant="outline" className="text-xs border-accent/50 text-accent bg-accent/10">
                        {originalKey} {originalKey.includes("m") ? "(menor)" : "(mayor)"}
                      </Badge>
                    </span>
                    {transpose !== 0 && (
                      <>
                        <span>→</span>
                        <Badge variant="secondary" className="text-xs bg-primary/10 text-primary">
                          {selectedKey} {selectedKey.includes("m") ? "(menor)" : "(mayor)"}
                        </Badge>
                        <Badge variant="outline" className="text-xs border-primary/30 text-primary">
                          {transpose > 0 ? "+" : ""}
                          {transpose} semitonos
                        </Badge>
                      </>
                    )}
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <label className="text-sm font-semibold text-foreground">Tamaño de texto</label>
                <div className="grid grid-cols-3 gap-2">
                  <Button
                    variant={fontSize === "small" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setFontSize("small")}
                    className={`text-xs h-8 sm:h-10 transition-all duration-300 ${
                      fontSize === "small"
                        ? "bg-gradient-to-r from-primary to-secondary shadow-lg"
                        : "bg-transparent border-2 border-secondary/50 text-primary hover:text-accent hover:border-accent/50"
                    }`}
                  >
                    XS
                  </Button>
                  <Button
                    variant={fontSize === "medium" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setFontSize("medium")}
                    className={`text-xs h-8 sm:h-10 transition-all duration-300 ${
                      fontSize === "medium"
                        ? "bg-gradient-to-r from-primary to-secondary shadow-lg"
                        : "bg-transparent border-2 border-secondary/50 text-primary hover:text-accent hover:border-accent/50"
                    }`}
                  >
                    S
                  </Button>
                  <Button
                    variant={fontSize === "large" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setFontSize("large")}
                    className={`text-xs h-8 sm:h-10 transition-all duration-300 ${
                      fontSize === "large"
                        ? "bg-gradient-to-r from-primary to-secondary shadow-lg"
                        : "bg-transparent border-2 border-secondary/50 text-primary hover:text-accent hover:border-accent/50"
                    }`}
                  >
                    M
                  </Button>
                </div>
              </div>
            </div>

            <div className="mt-4 sm:mt-6 pt-4 sm:pt-6 border-t border-secondary/30">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
                <span className="text-xs sm:text-sm font-semibold text-muted-foreground">Transposición rápida:</span>
                <div className="flex gap-2 w-full sm:w-auto">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      const currentIndex = availableKeys.indexOf(selectedKey)
                      const newIndex = currentIndex > 0 ? currentIndex - 1 : availableKeys.length - 1
                      setSelectedKey(availableKeys[newIndex])
                    }}
                    className="flex-1 sm:flex-none h-8 sm:h-10 text-xs text-primary hover:text-accent hover:bg-accent/10 transition-all duration-300"
                  >
                    <Minus className="w-3 h-3 sm:w-4 sm:h-4 mr-1" />
                    Anterior
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setSelectedKey(originalKey)}
                    className="flex-1 sm:flex-none h-8 sm:h-10 text-xs text-primary hover:text-accent hover:bg-accent/10 transition-all duration-300"
                  >
                    <RotateCcw className="w-3 h-3 sm:w-4 sm:h-4 mr-1" />
                    Original
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      const currentIndex = availableKeys.indexOf(selectedKey)
                      const newIndex = currentIndex < availableKeys.length - 1 ? currentIndex + 1 : 0
                      setSelectedKey(availableKeys[newIndex])
                    }}
                    className="flex-1 sm:flex-none h-8 sm:h-10 text-xs text-primary hover:text-accent hover:bg-accent/10 transition-all duration-300"
                  >
                    <Plus className="w-3 h-3 sm:w-4 sm:h-4 mr-1" />
                    Siguiente
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-primary/30 shadow-xl bg-gradient-to-br from-background to-primary/5">
          <CardHeader className="px-4 sm:px-6 py-4 sm:py-6">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg sm:text-xl text-primary flex items-center gap-2">
                <Music className="w-5 h-5 sm:w-6 sm:h-6" />
                {song.title}
                {transpose !== 0 && (
                  <Badge variant="secondary" className="ml-2 text-xs bg-accent/20 text-accent">
                    {selectedKey}
                  </Badge>
                )}
              </CardTitle>

              {/* Auto-scroll compacto integrado en el header */}
              <div className="flex items-center gap-2">
                <Button
                  variant={isAutoScrolling ? "default" : "outline"}
                  size="sm"
                  onClick={toggleAutoScroll}
                  className={`h-8 px-3 text-xs transition-all duration-300 ${
                    isAutoScrolling
                      ? "bg-green-600 hover:bg-green-700 text-white shadow-lg"
                      : "text-primary hover:text-accent hover:bg-accent/10 border border-primary/30"
                  }`}
                >
                  {isAutoScrolling ? (
                    <>
                      <Pause className="w-3 h-3 mr-1" />
                      Pausar
                    </>
                  ) : (
                    <>
                      <Play className="w-3 h-3 mr-1" />
                      Auto-Scroll
                    </>
                  )}
                </Button>

                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowAdvancedControls(!showAdvancedControls)}
                  className="h-8 w-8 p-0 text-primary hover:text-accent hover:bg-accent/10"
                >
                  {showAdvancedControls ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </Button>
              </div>
            </div>

            {/* Controles expandibles */}
            {showAdvancedControls && (
              <div className="mt-4 pt-4 border-t border-primary/20 space-y-3">
                {/* Primera fila: Botón inicio y controles de velocidad */}
                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={resetScroll}
                    className="h-8 px-3 text-xs text-primary hover:text-accent hover:bg-accent/10 w-full sm:w-auto"
                  >
                    <SkipBack className="w-3 h-3 mr-1" />
                    Al inicio
                  </Button>

                  <div className="flex items-center gap-2 w-full sm:w-auto justify-center sm:justify-start">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setScrollSpeed(Math.max(0.1, scrollSpeed - 0.1))} // Cambiar de 0.3 a 0.1
                      className="h-8 w-8 p-0 text-xs text-primary hover:text-accent hover:bg-accent/10 flex-shrink-0"
                    >
                      <Minus className="w-3 h-3" />
                    </Button>
                    <div className="text-xs text-muted-foreground min-w-[50px] text-center font-mono">
                      {getSpeedLabel(scrollSpeed)}
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setScrollSpeed(Math.min(3, scrollSpeed + 0.1))}
                      className="h-8 w-8 p-0 text-xs text-primary hover:text-accent hover:bg-accent/10 flex-shrink-0"
                    >
                      <Plus className="w-3 h-3" />
                    </Button>
                  </div>
                </div>

                {/* Segunda fila: Solo 3 presets para músicos */}
                <div className="grid grid-cols-3 gap-2">
                  {speedPresets.map((preset) => (
                    <Button
                      key={preset.value}
                      variant={Math.abs(scrollSpeed - preset.value) < 0.05 ? "default" : "ghost"}
                      size="sm"
                      onClick={() => setScrollSpeed(preset.value)}
                      className={`h-8 px-2 text-xs transition-all duration-300 ${
                        Math.abs(scrollSpeed - preset.value) < 0.05
                          ? "bg-primary text-white"
                          : "text-primary hover:text-accent hover:bg-accent/10"
                      }`}
                      title={preset.description}
                    >
                      {preset.label}
                    </Button>
                  ))}
                </div>

                {/* 🎵 INFORMACIÓN PARA MÚSICOS */}
                <div className="text-xs text-muted-foreground bg-muted/30 p-2 rounded">
                  🎵 <strong>Para músicos:</strong> Ajusta la velocidad según el tempo de tu canción. Puedes bajar hasta
                  0.1x para lectura muy lenta, usar los presets (0.3x, 0.6x, 1.0x) para velocidades comunes, o subir
                  hasta 3.0x para práctica rápida. El scroll se pausa automáticamente al final.
                </div>
              </div>
            )}
          </CardHeader>
          <CardContent className="px-4 sm:px-6 pb-6 sm:pb-8">
            <div
              ref={normalScrollContainerRef}
              className="bg-gradient-to-br from-muted/30 to-background border border-primary/20 rounded-lg p-4 sm:p-6 shadow-inner max-h-[600px] overflow-y-auto overflow-x-hidden"
              style={{
                scrollBehavior: "auto", // Cambiado de "smooth" a "auto" para mejor control
                WebkitOverflowScrolling: "touch", // Para mejor scroll en iOS
              }}
            >
              <div className="space-y-1 sm:space-y-2">
                {processedSections.map((section, index) => renderSection(section, index))}
                {/* Espacio extra al final para mejor scroll */}
                <div className="h-16"></div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  )
}
