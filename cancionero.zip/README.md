# 🎵 Cancionero Interactivo

Una aplicación web moderna para gestionar y visualizar cantos litúrgicos con transposición automática de acordes.

## ✨ Características

- 📱 **Completamente responsive** - Funciona perfectamente en móviles, tablets y desktop
- 🎸 **Transposición automática** - Cambia la tonalidad de cualquier canción al instante
- 🎵 **Reconocimiento inteligente de acordes** - Detecta automáticamente acordes en español e inglés
- 🔊 **Reproductor de audio integrado** - Sube y reproduce archivos de audio
- 📂 **Organización por categorías** - Separa cantos de misa y cantos generales
- 💾 **Almacenamiento local** - Tus canciones se guardan en el navegador
- 🎨 **Diseño contemplativo** - Interfaz elegante y minimalista

## 🚀 Tecnologías

- **Next.js 14** - Framework de React
- **TypeScript** - Tipado estático
- **Tailwind CSS** - Estilos utilitarios
- **Shadcn/ui** - Componentes de interfaz
- **Lucide React** - Iconos modernos

## 📱 Uso

1. **Crear canciones** - Añade título, letra con acordes y audio opcional
2. **Organizar** - Clasifica en "Cancionero de Misa" o "Cancionero" general
3. **Transponer** - Cambia la tonalidad con un clic
4. **Tocar** - Visualización optimizada para guitarristas en móvil

## 🎼 Formato de Acordes

La aplicación reconoce acordes en:
- **Inglés**: C, D, E, F, G, A, B (con variaciones como Cm, C7, etc.)
- **Español**: DO, RE, MI, FA, SOL, LA, SI (con variaciones como REm, LA7, etc.)

## 🔧 Desarrollo

\`\`\`bash
# Instalar dependencias
npm install

# Ejecutar en desarrollo
npm run dev

# Construir para producción
npm run build

# Ejecutar en producción
npm start
\`\`\`

## 📄 Licencia

Este proyecto está bajo la Licencia MIT.
