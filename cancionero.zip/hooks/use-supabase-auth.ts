"use client"

import { useState, useEffect } from "react"
import { authService, isSupabaseConfigured } from "@/lib/supabase"
import type { User } from "@supabase/supabase-js"

export function useSupabaseAuth() {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  useEffect(() => {
    // Si Supabase no está configurado, no intentar autenticación
    if (!isSupabaseConfigured) {
      console.log('⚠️ Supabase not configured, skipping auth check')
      setUser(null)
      setIsAuthenticated(false)
      setIsLoading(false)
      return
    }

    // Verificar estado inicial
    const checkAuth = async () => {
      try {
        console.log('🔍 Checking authentication status...')
        const currentUser = await authService.getCurrentUser()
        setUser(currentUser)
        setIsAuthenticated(!!currentUser)
        console.log('✅ Auth check complete:', !!currentUser)
      } catch (error) {
        console.error('❌ Error checking auth:', error)
        setUser(null)
        setIsAuthenticated(false)
      } finally {
        setIsLoading(false)
      }
    }

    checkAuth()

    // Verificar cada 30 segundos solo si Supabase está configurado
    const interval = setInterval(checkAuth, 30000)

    return () => clearInterval(interval)
  }, [])

  const login = async (email: string, password: string): Promise<boolean> => {
    if (!isSupabaseConfigured) {
      console.error('❌ Cannot login: Supabase not configured')
      throw new Error('Base de datos no configurada. Contacta al administrador.')
    }

    try {
      console.log('🔐 Attempting login...')
      const { user: loggedInUser } = await authService.signIn(email, password)
      setUser(loggedInUser)
      setIsAuthenticated(true)
      console.log('✅ Login successful')
      return true
    } catch (error: any) {
      console.error('❌ Login error:', error)
      setUser(null)
      setIsAuthenticated(false)
      throw error // Re-lanzar para que el componente pueda manejar el error
    }
  }

  const logout = async () => {
    try {
      console.log('🚪 Logging out...')
      await authService.signOut()
      setUser(null)
      setIsAuthenticated(false)
      console.log('✅ Logout successful')
    } catch (error) {
      console.error('❌ Logout error:', error)
      // Limpiar estado local incluso si hay error
      setUser(null)
      setIsAuthenticated(false)
    }
  }

  return {
    user,
    isAuthenticated,
    isLoading,
    login,
    logout,
    isSupabaseConfigured, // Exponer esta información
  }
}
