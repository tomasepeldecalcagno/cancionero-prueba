"use client"

import { useState, useEffect } from "react"
import AuthManager from "@/lib/auth"

export function useAuth() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Verificar estado inicial
    const checkAuth = () => {
      const authenticated = AuthManager.isAuthenticated()
      setIsAuthenticated(authenticated)
      setIsLoading(false)
    }

    checkAuth()

    // Verificar cada 30 segundos
    const interval = setInterval(() => {
      const authenticated = AuthManager.isAuthenticated()
      setIsAuthenticated(authenticated)
    }, 30000)

    return () => clearInterval(interval)
  }, [])

  const login = (code: string): boolean => {
    const success = AuthManager.login(code)
    if (success) {
      setIsAuthenticated(true)
    }
    return success
  }

  const logout = () => {
    AuthManager.logout()
    setIsAuthenticated(false)
  }

  const requireAuth = (callback: () => void): (() => void) => {
    return () => {
      if (isAuthenticated) {
        callback()
      } else {
        // Aquí podrías mostrar el diálogo de autenticación
        console.log("Authentication required")
      }
    }
  }

  return {
    isAuthenticated,
    isLoading,
    login,
    logout,
    requireAuth,
    timeRemaining: AuthManager.getSessionTimeRemaining(),
  }
}
