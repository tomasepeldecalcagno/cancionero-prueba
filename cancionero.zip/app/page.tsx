"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Plus, Music, Search, Edit, Trash2, Volume2, Cross, Loader2, AlertCircle, Wifi, WifiOff } from "lucide-react"
import SongForm from "@/components/song-form"
import SongViewer from "@/components/song-viewer"
import { songService, isSupabaseConfigured, type Song } from "@/lib/supabase"

export default function Home() {
  const [songs, setSongs] = useState<Song[]>([])
  const [currentView, setCurrentView] = useState<"list" | "add" | "view" | "edit">("list")
  const [selectedSong, setSelectedSong] = useState<Song | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Cargar canciones al iniciar
  useEffect(() => {
    const loadSongs = async () => {
      try {
        setIsLoading(true)
        console.log("🔄 Loading songs...")
        const loadedSongs = await songService.getAllSongs()
        console.log(`✅ Loaded ${loadedSongs.length} songs`)
        setSongs(loadedSongs)
        setError(null)
      } catch (error) {
        console.error("❌ Error loading songs:", error)
        setError("Error al cargar las canciones. Usando almacenamiento local.")
      } finally {
        setIsLoading(false)
      }
    }

    loadSongs()
  }, [])

  const addSong = async (song: Omit<Song, "id">) => {
    try {
      setIsLoading(true)
      console.log("🔄 Creating song:", song.title)
      const newSong = await songService.createSong({
        ...song,
        category: song.category || "general",
      })
      console.log("✅ Song created:", newSong)
      setSongs((prev) => [...prev, newSong])
      setCurrentView("list")
      setError(null)
    } catch (error) {
      console.error("❌ Error creating song:", error)
      setError("Error al crear la canción. Inténtalo de nuevo.")
    } finally {
      setIsLoading(false)
    }
  }

  const updateSong = async (updatedSong: Song) => {
    try {
      setIsLoading(true)
      console.log("🔄 Updating song:", updatedSong.title)
      const updated = await songService.updateSong(updatedSong.id, updatedSong)
      console.log("✅ Song updated:", updated)
      setSongs((prev) => prev.map((song) => (song.id === updatedSong.id ? updated : song)))
      setCurrentView("list")
      setError(null)
    } catch (error) {
      console.error("❌ Error updating song:", error)
      setError("Error al actualizar la canción. Inténtalo de nuevo.")
    } finally {
      setIsLoading(false)
    }
  }

  const deleteSong = async (id: string) => {
    try {
      setIsLoading(true)
      console.log("🔄 Deleting song:", id)
      await songService.deleteSong(id)
      console.log("✅ Song deleted")
      setSongs((prev) => prev.filter((song) => song.id !== id))
      setCurrentView("list")
      setError(null)
    } catch (error) {
      console.error("❌ Error deleting song:", error)
      setError("Error al eliminar la canción. Inténtalo de nuevo.")
    } finally {
      setIsLoading(false)
    }
  }

  // Función para normalizar texto (quitar tildes, puntuación y convertir a minúsculas)
  const normalizeText = (text: string): string => {
    return text
      .toLowerCase()
      .normalize("NFD") // Descompone caracteres con tildes
      .replace(/[\u0300-\u036f]/g, "") // Remueve las tildes
      .replace(/[^\w\s]/g, "") // Remueve signos de puntuación
      .replace(/\s+/g, " ") // Normaliza espacios múltiples a uno solo
      .trim()
  }

  const filteredSongs = songs.filter((song) => {
    const normalizedTitle = normalizeText(song.title)
    const normalizedSearch = normalizeText(searchTerm)
    return normalizedTitle.includes(normalizedSearch)
  })

  const renderContent = () => {
    switch (currentView) {
      case "add":
        return <SongForm onSave={addSong} onCancel={() => setCurrentView("list")} />
      case "edit":
        return selectedSong ? (
          <SongForm song={selectedSong} onSave={updateSong} onCancel={() => setCurrentView("list")} />
        ) : null
      case "view":
        return selectedSong ? (
          <SongViewer
            song={selectedSong}
            onBack={() => setCurrentView("list")}
            onEdit={() => {
              setCurrentView("edit")
            }}
            onDelete={() => {
              if (confirm(`¿Estás seguro de que quieres eliminar "${selectedSong.title}"?`)) {
                deleteSong(selectedSong.id)
              }
            }}
          />
        ) : null
      default:
        return (
          <div className="space-y-6 sm:space-y-8 animate-fade-in-up">
            {/* Estado de conexión */}
            <div className="flex justify-center px-4">
              <Badge
                variant="outline"
                className={`flex items-center gap-2 px-3 py-1 text-xs ${
                  isSupabaseConfigured
                    ? "bg-green-50 text-green-700 border-green-200"
                    : "bg-yellow-50 text-yellow-700 border-yellow-200"
                }`}
              >
                {isSupabaseConfigured ? (
                  <>
                    <Wifi className="w-3 h-3" />
                    Base de datos conectada
                  </>
                ) : (
                  <>
                    <WifiOff className="w-3 h-3" />
                    Modo local
                  </>
                )}
              </Badge>
            </div>

            {/* Error Alert */}
            {error && (
              <div className="bg-yellow-50 border-yellow-200 text-yellow-800 p-4 rounded-lg mb-4 mx-4">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-4 h-4" />
                  <span>{error}</span>
                </div>
              </div>
            )}

            {/* Hero Section Responsive */}
            <div className="text-center py-8 sm:py-12 px-4">
              <div className="inline-flex items-center justify-center w-12 h-12 sm:w-16 sm:h-16 bg-contemplative-gradient rounded-lg mb-4 sm:mb-6 shadow-subtle">
                <span className="text-white text-xl sm:text-2xl font-light">†</span>
              </div>

              <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold mb-6 sm:mb-8 text-contemplative-gradient px-4">
                Cancionero
              </h1>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                <Button
                  onClick={() => setCurrentView("add")}
                  size="lg"
                  className="w-full sm:w-auto bg-contemplative-gradient hover:bg-reflective-gradient shadow-subtle hover:shadow-subtle-hover transition-all duration-300 btn-contemplative text-white font-medium px-6 py-3 rounded-lg text-sm sm:text-base"
                >
                  <Plus className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
                  Nueva Canción
                </Button>
              </div>

              <div className="mt-8 sm:mt-10 mb-4 sm:mb-6">
                <div className="subtle-contemplative-divider"></div>
              </div>
            </div>

            {/* Search Responsive */}
            <div className="relative max-w-sm sm:max-w-md mx-auto px-4">
              <Search className="absolute left-6 sm:left-7 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="Buscar canciones..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 sm:pl-10 h-10 sm:h-10 border border-contemplative-200 focus:border-contemplative-400 rounded-lg shadow-subtle focus:shadow-glow-sm transition-all duration-200 bg-white font-medium focus-contemplative text-sm sm:text-base"
              />
            </div>

            {/* Loading State */}
            {isLoading ? (
              <div className="flex justify-center items-center py-12">
                <div className="flex items-center gap-3">
                  <Loader2 className="w-6 h-6 animate-spin text-contemplative" />
                  <span className="text-contemplative">Cargando canciones...</span>
                </div>
              </div>
            ) : (
              <>
                {/* Stats Responsive */}
                <div className="flex justify-center px-4">
                  <Badge
                    variant="secondary"
                    className="flex items-center gap-2 px-3 sm:px-4 py-2 bg-reflective-gradient text-white shadow-subtle text-xs sm:text-sm font-medium rounded-full"
                  >
                    {songs.length} {songs.length === 1 ? "canción" : "canciones"} total
                  </Badge>
                </div>

                {/* Songs List Responsive */}
                {filteredSongs.length === 0 ? (
                  <div className="px-4">
                    <Card className="text-center py-12 sm:py-16 border border-contemplative-200 bg-white/80 backdrop-blur-sm card-subtle rounded-lg">
                      <CardContent className="px-4">
                        <div className="inline-flex items-center justify-center w-10 h-10 sm:w-12 sm:h-12 bg-reflective-gradient rounded-lg mb-4">
                          <Cross className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                        </div>
                        <h3 className="text-lg sm:text-xl font-semibold text-contemplative-700 mb-3 px-4">
                          {songs.length === 0 ? "Comienza tu colección de canciones" : "No se encontraron canciones"}
                        </h3>
                        <p className="text-sm sm:text-base text-muted-foreground mb-6 max-w-sm mx-auto px-4">
                          {songs.length === 0
                            ? "Crea tu primera canción para la liturgia o la adoración"
                            : "Intenta con otros términos de búsqueda"}
                        </p>
                        {songs.length === 0 && (
                          <Button
                            onClick={() => setCurrentView("add")}
                            className="w-full sm:w-auto bg-reflective-gradient hover:bg-contemplative-gradient shadow-subtle hover:shadow-subtle-hover transition-all duration-300 text-white font-medium px-4 py-2 rounded-lg text-sm sm:text-base"
                          >
                            <Plus className="w-4 h-4 mr-2" />
                            Crear Primera Canción
                          </Button>
                        )}
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <div className="space-y-8 sm:space-y-12 px-4">
                    {/* Sección Cancionero de Misa Responsive */}
                    {(() => {
                      const misaSongs = filteredSongs
                        .filter((song) => song.category === "misa")
                        .sort((a, b) => a.title.localeCompare(b.title, "es", { sensitivity: "base" }))
                      return (
                        misaSongs.length > 0 && (
                          <div className="space-y-4 sm:space-y-6">
                            <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                              <div className="flex items-center gap-3">
                                <div className="w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-br from-contemplative to-reflective rounded-lg flex items-center justify-center shadow-lg">
                                  <Music className="w-3 h-3 sm:w-4 sm:h-4 text-white" />
                                </div>
                                <h2 className="text-lg sm:text-xl font-bold text-contemplative">Cancionero de Misa</h2>
                              </div>
                              <Badge
                                variant="secondary"
                                className="bg-contemplative/20 text-contemplative border-contemplative/30 text-xs sm:text-sm w-fit"
                              >
                                {misaSongs.length} {misaSongs.length === 1 ? "canción" : "canciones"}
                              </Badge>
                            </div>
                            <div className="grid gap-3 sm:gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5">
                              {misaSongs.map((song) => (
                                <Card
                                  key={song.id}
                                  className="group card-subtle border border-contemplative-200 bg-white/90 backdrop-blur-sm overflow-hidden rounded-lg"
                                >
                                  <CardHeader className="pb-2 px-3 sm:px-4 pt-3">
                                    <div className="absolute top-2 right-2 sm:right-3 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                                      {song.audio_file && (
                                        <div className="w-4 h-4 sm:w-5 sm:h-5 bg-contemplative-500 rounded-full flex items-center justify-center">
                                          <Volume2 className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-white" />
                                        </div>
                                      )}
                                    </div>
                                    <CardTitle className="text-xs sm:text-sm font-semibold text-contemplative-700 line-clamp-2 leading-tight pr-6">
                                      {song.title}
                                    </CardTitle>
                                  </CardHeader>

                                  <CardContent className="px-3 sm:px-4 pb-3">
                                    <div className="flex flex-col gap-2">
                                      {song.audio_file && (
                                        <div className="w-full">
                                          <audio
                                            controls
                                            className="w-full rounded shadow-sm"
                                            style={{ height: "24px" }}
                                            preload="none"
                                          >
                                            <source src={song.audio_file} type="audio/mpeg" />
                                            <source src={song.audio_file} type="audio/wav" />
                                            <source src={song.audio_file} type="audio/ogg" />
                                            Tu navegador no soporta el elemento de audio.
                                          </audio>
                                        </div>
                                      )}

                                      <div className="flex gap-1">
                                        <Button
                                          variant="outline"
                                          size="sm"
                                          className="flex-1 h-7 sm:h-8 text-xs bg-white border-contemplative-300 text-contemplative-700 hover:bg-contemplative-50 hover:border-contemplative-400 transition-all duration-200 shadow-sm rounded font-medium"
                                          onClick={() => {
                                            setSelectedSong(song)
                                            setCurrentView("view")
                                          }}
                                        >
                                          <Music className="w-2.5 h-2.5 sm:w-3 sm:h-3 mr-1" />
                                          Ver
                                        </Button>
                                        <Button
                                          variant="ghost"
                                          size="icon"
                                          className="h-7 w-7 sm:h-8 sm:w-8 text-contemplative-600 hover:text-contemplative-700 hover:bg-contemplative-50 transition-all duration-200 rounded"
                                          onClick={(e) => {
                                            e.stopPropagation()
                                            setSelectedSong(song)
                                            setCurrentView("edit")
                                          }}
                                        >
                                          <Edit className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                                        </Button>
                                        <Button
                                          variant="ghost"
                                          size="icon"
                                          className="h-7 w-7 sm:h-8 sm:w-8 text-contemplative-600 hover:text-red-600 hover:bg-red-50 transition-all duration-200 rounded"
                                          onClick={(e) => {
                                            e.stopPropagation()
                                            if (confirm(`¿Estás seguro de que quieres eliminar "${song.title}"?`)) {
                                              deleteSong(song.id)
                                            }
                                          }}
                                        >
                                          <Trash2 className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                                        </Button>
                                      </div>
                                    </div>
                                  </CardContent>
                                </Card>
                              ))}
                            </div>
                          </div>
                        )
                      )
                    })()}

                    {/* Sección Cancionero General Responsive */}
                    {(() => {
                      const generalSongs = filteredSongs
                        .filter((song) => song.category === "general" || !song.category)
                        .sort((a, b) => a.title.localeCompare(b.title, "es", { sensitivity: "base" }))
                      return (
                        generalSongs.length > 0 && (
                          <div className="space-y-4 sm:space-y-6">
                            <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                              <div className="flex items-center gap-3">
                                <div className="w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-br from-reflective to-contemplative rounded-lg flex items-center justify-center shadow-lg">
                                  <Music className="w-3 h-3 sm:w-4 sm:h-4 text-white" />
                                </div>
                                <h2 className="text-lg sm:text-xl font-bold text-contemplative">Cancionero</h2>
                              </div>
                              <Badge
                                variant="secondary"
                                className="bg-reflective/20 text-reflective border-reflective/30 text-xs sm:text-sm w-fit"
                              >
                                {generalSongs.length} {generalSongs.length === 1 ? "canción" : "canciones"}
                              </Badge>
                            </div>
                            <div className="grid gap-3 sm:gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5">
                              {generalSongs.map((song) => (
                                <Card
                                  key={song.id}
                                  className="group card-subtle border border-contemplative-200 bg-white/90 backdrop-blur-sm overflow-hidden rounded-lg"
                                >
                                  <CardHeader className="pb-2 px-3 sm:px-4 pt-3">
                                    <div className="absolute top-2 right-2 sm:right-3 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                                      {song.audio_file && (
                                        <div className="w-4 h-4 sm:w-5 sm:h-5 bg-contemplative-500 rounded-full flex items-center justify-center">
                                          <Volume2 className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-white" />
                                        </div>
                                      )}
                                    </div>
                                    <CardTitle className="text-xs sm:text-sm font-semibold text-contemplative-700 line-clamp-2 leading-tight pr-6">
                                      {song.title}
                                    </CardTitle>
                                  </CardHeader>

                                  <CardContent className="px-3 sm:px-4 pb-3">
                                    <div className="flex flex-col gap-2">
                                      {song.audio_file && (
                                        <div className="w-full">
                                          <audio
                                            controls
                                            className="w-full rounded shadow-sm"
                                            style={{ height: "24px" }}
                                            preload="none"
                                          >
                                            <source src={song.audio_file} type="audio/mpeg" />
                                            <source src={song.audio_file} type="audio/wav" />
                                            <source src={song.audio_file} type="audio/ogg" />
                                            Tu navegador no soporta el elemento de audio.
                                          </audio>
                                        </div>
                                      )}

                                      <div className="flex gap-1">
                                        <Button
                                          variant="outline"
                                          size="sm"
                                          className="flex-1 h-7 sm:h-8 text-xs bg-white border-contemplative-300 text-contemplative-700 hover:bg-contemplative-50 hover:border-contemplative-400 transition-all duration-200 shadow-sm rounded font-medium"
                                          onClick={() => {
                                            setSelectedSong(song)
                                            setCurrentView("view")
                                          }}
                                        >
                                          <Music className="w-2.5 h-2.5 sm:w-3 sm:h-3 mr-1" />
                                          Ver
                                        </Button>
                                        <Button
                                          variant="ghost"
                                          size="icon"
                                          className="h-7 w-7 sm:h-8 sm:w-8 text-contemplative-600 hover:text-contemplative-700 hover:bg-contemplative-50 transition-all duration-200 rounded"
                                          onClick={(e) => {
                                            e.stopPropagation()
                                            setSelectedSong(song)
                                            setCurrentView("edit")
                                          }}
                                        >
                                          <Edit className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                                        </Button>
                                        <Button
                                          variant="ghost"
                                          size="icon"
                                          className="h-7 w-7 sm:h-8 sm:w-8 text-contemplative-600 hover:text-red-600 hover:bg-red-50 transition-all duration-200 rounded"
                                          onClick={(e) => {
                                            e.stopPropagation()
                                            if (confirm(`¿Estás seguro de que quieres eliminar "${song.title}"?`)) {
                                              deleteSong(song.id)
                                            }
                                          }}
                                        >
                                          <Trash2 className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                                        </Button>
                                      </div>
                                    </div>
                                  </CardContent>
                                </Card>
                              ))}
                            </div>
                          </div>
                        )
                      )
                    })()}
                  </div>
                )}
              </>
            )}
          </div>
        )
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-contemplative-50/10">
      <div className="container mx-auto px-3 sm:px-4 lg:px-6 py-4 sm:py-6 lg:py-10 max-w-7xl">{renderContent()}</div>
    </div>
  )
}
