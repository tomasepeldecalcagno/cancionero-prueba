"use client"

// Configuración de autenticación
const AUTH_CONFIG = {
  // Código de acceso actualizado
  ACCESS_CODE: "3149",
  // Tiempo de sesión en milisegundos (24 horas)
  SESSION_DURATION: 24 * 60 * 60 * 1000,
  // Clave para localStorage
  STORAGE_KEY: "cancionero-auth",
}

export interface AuthSession {
  isAuthenticated: boolean
  timestamp: number
  expiresAt: number
}

export class AuthManager {
  /**
   * Verifica si el código de acceso es correcto
   */
  static verifyCode(code: string): boolean {
    return code.trim() === AUTH_CONFIG.ACCESS_CODE
  }

  /**
   * Inicia sesión con el código proporcionado
   */
  static login(code: string): boolean {
    if (!this.verifyCode(code)) {
      return false
    }

    const now = Date.now()
    const session: AuthSession = {
      isAuthenticated: true,
      timestamp: now,
      expiresAt: now + AUTH_CONFIG.SESSION_DURATION,
    }

    try {
      localStorage.setItem(AUTH_CONFIG.STORAGE_KEY, JSON.stringify(session))
      return true
    } catch (error) {
      console.error("Error saving auth session:", error)
      return false
    }
  }

  /**
   * Cierra la sesión actual
   */
  static logout(): void {
    try {
      localStorage.removeItem(AUTH_CONFIG.STORAGE_KEY)
    } catch (error) {
      console.error("Error removing auth session:", error)
    }
  }

  /**
   * Verifica si el usuario está autenticado
   */
  static isAuthenticated(): boolean {
    try {
      const sessionData = localStorage.getItem(AUTH_CONFIG.STORAGE_KEY)
      if (!sessionData) return false

      const session: AuthSession = JSON.parse(sessionData)
      const now = Date.now()

      // Verificar si la sesión ha expirado
      if (now > session.expiresAt) {
        this.logout()
        return false
      }

      return session.isAuthenticated
    } catch (error) {
      console.error("Error checking auth status:", error)
      this.logout()
      return false
    }
  }

  /**
   * Obtiene información de la sesión actual
   */
  static getSession(): AuthSession | null {
    try {
      const sessionData = localStorage.getItem(AUTH_CONFIG.STORAGE_KEY)
      if (!sessionData) return null

      const session: AuthSession = JSON.parse(sessionData)
      const now = Date.now()

      if (now > session.expiresAt) {
        this.logout()
        return null
      }

      return session
    } catch (error) {
      console.error("Error getting session:", error)
      return null
    }
  }

  /**
   * Extiende la sesión actual
   */
  static extendSession(): boolean {
    try {
      const session = this.getSession()
      if (!session) return false

      const now = Date.now()
      const extendedSession: AuthSession = {
        ...session,
        expiresAt: now + AUTH_CONFIG.SESSION_DURATION,
      }

      localStorage.setItem(AUTH_CONFIG.STORAGE_KEY, JSON.stringify(extendedSession))
      return true
    } catch (error) {
      console.error("Error extending session:", error)
      return false
    }
  }

  /**
   * Obtiene el tiempo restante de la sesión en minutos
   */
  static getSessionTimeRemaining(): number {
    const session = this.getSession()
    if (!session) return 0

    const now = Date.now()
    const remaining = session.expiresAt - now
    return Math.max(0, Math.floor(remaining / (1000 * 60)))
  }
}

export default AuthManager
