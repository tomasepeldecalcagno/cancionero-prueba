import type { Config } from "tailwindcss"

const config = {
  darkMode: ["class"],
  content: [
    './pages/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './app/**/*.{ts,tsx}',
    './src/**/*.{ts,tsx}',
    '*.{js,ts,jsx,tsx,mdx}',
  ],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
          50: "#f6f7f4",
          100: "#e9ebe4",
          200: "#d4d8ca",
          300: "#b8bfa8",
          400: "#9ca587",
          500: "#6b705c",
          600: "#5a5f4d",
          700: "#4a4e40",
          800: "#3d4035",
          900: "#33362d",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
          50: "#f7f7f4",
          100: "#ededdf",
          200: "#dcdcc1",
          300: "#c6c69d",
          400: "#b5b58a",
          500: "#a5a58d",
          600: "#8f8f77",
          700: "#757562",
          800: "#616152",
          900: "#525245",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
          50: "#f5f6f2",
          100: "#e8eae1",
          200: "#d1d6c4",
          300: "#b8bfa8",
          400: "#9ca587",
          500: "#8b956d",
          600: "#757f5e",
          700: "#60684f",
          800: "#4f5543",
          900: "#424739",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        // Colores contemplativos
        contemplative: {
          DEFAULT: "#5a6b7d",
          50: "#f4f6f8",
          100: "#e8ecf0",
          200: "#d1d9e1",
          300: "#b0bcc8",
          400: "#8a9aab",
          500: "#6d7d91",
          600: "#5a6b7d",
          700: "#4c5a68",
          800: "#414c57",
          900: "#39424a",
        },
        // Colores reflexivos
        reflective: {
          DEFAULT: "#6b7280",
          50: "#f9fafb",
          100: "#f3f4f6",
          200: "#e5e7eb",
          300: "#d1d5db",
          400: "#9ca3af",
          500: "#6b7280",
          600: "#4b5563",
          700: "#374151",
          800: "#1f2937",
          900: "#111827",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
        "fade-in-up": {
          from: { opacity: "0", transform: "translateY(10px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "fade-in-up": "fade-in-up 0.4s ease-out",
      },
      backgroundImage: {
        "gradient-radial": "radial-gradient(var(--tw-gradient-stops))",
        "gradient-conic": "conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))",
        "contemplative-gradient": "linear-gradient(135deg, #5a6b7d 0%, #6b7280 100%)",
        "reflective-gradient": "linear-gradient(135deg, #6b7280 0%, #5a6b7d 100%)",
      },
      boxShadow: {
        "glow-sm": "0 0 6px rgba(90, 107, 125, 0.1)",
        "glow-md": "0 0 10px rgba(90, 107, 125, 0.12)",
        subtle: "0 2px 8px rgba(90, 107, 125, 0.06)",
        "subtle-hover": "0 4px 12px rgba(90, 107, 125, 0.08)",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
} satisfies Config

export default config
