-- Crear tabla de canciones
CREATE TABLE IF NOT EXISTS songs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  artist TEXT,
  lyrics TEXT NOT NULL,
  original_key TEXT,
  audio_file TEXT, -- Base64 encoded audio
  audio_file_name TEXT,
  category TEXT NOT NULL DEFAULT 'general' CHECK (category IN ('misa', 'general')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Habilitar Row Level Security
ALTER TABLE songs ENABLE ROW LEVEL SECURITY;

-- Política para permitir lectura a todos (anónimos y autenticados)
CREATE POLICY "Anyone can read songs" ON songs
  FOR SELECT USING (true);

-- Política para permitir inserción solo a usuarios autenticados
CREATE POLICY "Authenticated users can insert songs" ON songs
  FOR INSERT WITH CHECK (auth.role() = 'authenticated');

-- Política para permitir actualización solo a usuarios autenticados
CREATE POLICY "Authenticated users can update songs" ON songs
  FOR UPDATE USING (auth.role() = 'authenticated');

-- Política para permitir eliminación solo a usuarios autenticados
CREATE POLICY "Authenticated users can delete songs" ON songs
  FOR DELETE USING (auth.role() = 'authenticated');

-- Función para actualizar updated_at automáticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Trigger para actualizar updated_at
CREATE TRIGGER update_songs_updated_at 
    BEFORE UPDATE ON songs 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

-- Insertar algunas canciones de ejemplo (opcional)
INSERT INTO songs (title, lyrics, original_key, category) VALUES 
(
  'Gloria a Dios en las Alturas',
  'DO      SOL     LAm     FA
Gloria a Dios en las alturas
DO      SOL     FA      DO
Y en la tierra paz a los hombres

SOL     LAm     FA      DO
Que ama el Señor, que ama el Señor
SOL     LAm     FA      DO
Gloria a Dios en las alturas',
  'C',
  'misa'
),
(
  'Alabaré',
  'RE      LA      SOL     RE
Alabaré, alabaré, alabaré a mi Señor
RE      LA      SOL     RE
Alabaré, alabaré, alabaré a mi Señor

SOL     RE      LA      RE
Juan vio el número de los redimidos
SOL     RE      LA      RE
Y todos alababan al Señor
SOL     RE      LA      RE
Unos cantaban, otros oraban
SOL     RE      LA      RE
Pero todos alababan al Señor',
  'D',
  'general'
);
