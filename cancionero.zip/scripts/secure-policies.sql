-- Eliminar políticas públicas
DROP POLICY IF EXISTS "Public can read songs" ON songs;
DROP POLICY IF EXISTS "Public can insert songs" ON songs;
DROP POLICY IF EXISTS "Public can update songs" ON songs;
DROP POLICY IF EXISTS "Public can delete songs" ON songs;

-- Políticas más seguras: solo usuarios autenticados
CREATE POLICY "Authenticated users can read songs" ON songs
  FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Authenticated users can insert songs" ON songs
  FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Authenticated users can update songs" ON songs
  FOR UPDATE USING (auth.role() = 'authenticated');

CREATE POLICY "Authenticated users can delete songs" ON songs
  FOR DELETE USING (auth.role() = 'authenticated');

-- Mantener RLS habilitado
ALTER TABLE songs ENABLE ROW LEVEL SECURITY;
