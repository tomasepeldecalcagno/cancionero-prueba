-- Eliminar políticas existentes
DROP POLICY IF EXISTS "Anyone can read songs" ON songs;
DROP POLICY IF EXISTS "Authenticated users can insert songs" ON songs;
DROP POLICY IF EXISTS "Authenticated users can update songs" ON songs;
DROP POLICY IF EXISTS "Authenticated users can delete songs" ON songs;

-- Crear políticas que permitan acceso público (sin autenticación)
CREATE POLICY "Public can read songs" ON songs
  FOR SELECT USING (true);

CREATE POLICY "Public can insert songs" ON songs
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Public can update songs" ON songs
  FOR UPDATE USING (true);

CREATE POLICY "Public can delete songs" ON songs
  FOR DELETE USING (true);

-- Verificar que RLS esté habilitado
ALTER TABLE songs ENABLE ROW LEVEL SECURITY;
